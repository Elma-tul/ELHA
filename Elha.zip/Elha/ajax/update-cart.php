<?php
// =====================================================
// AJAX: UPDATE CART QUANTITY
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$product_id = (int)($_POST['product_id'] ?? 0);
$quantity = (int)($_POST['quantity'] ?? 0);

if ($product_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid product.']);
    exit();
}

try {
    if ($quantity <= 0) {
        // Remove from cart
        $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
    } else {
        // Check stock
        $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $stock = (int)$stmt->fetchColumn();
        
        if ($quantity > $stock) {
            echo json_encode(['success' => false, 'message' => 'Not enough stock.']);
            exit();
        }
        
        // Update quantity
        $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$quantity, $user_id, $product_id]);
    }
    
    // Get updated cart data
    $stmt = $pdo->prepare("
        SELECT c.quantity, p.id, p.name, COALESCE(p.discount_price, p.price) as price, p.stock
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $items = $stmt->fetchAll();
    
    $subtotal = 0;
    $total_items = 0;
    foreach ($items as $item) {
        $subtotal += $item['quantity'] * $item['price'];
        $total_items += $item['quantity'];
    }
    
    echo json_encode([
        'success' => true,
        'subtotal' => $subtotal,
        'total_items' => $total_items,
        'items' => $items
    ]);
    
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error.']);
}
?>