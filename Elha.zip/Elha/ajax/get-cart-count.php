<?php
// =====================================================
// AJAX: GET CART COUNT
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['total' => 0]);
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    $stmt = $pdo->prepare("SELECT SUM(quantity) FROM cart WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total = (int)$stmt->fetchColumn();
    
    echo json_encode(['total' => $total]);
} catch(PDOException $e) {
    echo json_encode(['total' => 0]);
}
?>