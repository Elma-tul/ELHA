<?php
// =====================================================
// AJAX: SUBMIT STAR RATING
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login to rate this product.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$product_id = (int)($_POST['product_id'] ?? 0);
$rating = (int)($_POST['rating'] ?? 0);

// Validate
if ($product_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid product.']);
    exit();
}

if ($rating < 1 || $rating > 5) {
    echo json_encode(['success' => false, 'message' => 'Please select a rating from 1 to 5 stars.']);
    exit();
}

try {
    // Check if user already rated this product
    $stmt = $pdo->prepare("SELECT id FROM reviews WHERE user_id = ? AND product_id = ?");
    $stmt->execute([$user_id, $product_id]);
    $existing = $stmt->fetch();
    
    if ($existing) {
        // Update existing rating
        $stmt = $pdo->prepare("UPDATE reviews SET rating = ? WHERE user_id = ? AND product_id = ?");
        $result = $stmt->execute([$rating, $user_id, $product_id]);
    } else {
        // Insert new rating
        $stmt = $pdo->prepare("INSERT INTO reviews (user_id, product_id, rating) VALUES (?, ?, ?)");
        $result = $stmt->execute([$user_id, $product_id, $rating]);
    }
    
    // Calculate new average rating
    $stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total FROM reviews WHERE product_id = ?");
    $stmt->execute([$product_id]);
    $result = $stmt->fetch();
    
    $avg_rating = round($result['avg_rating'] ?? 0, 1);
    $total_ratings = (int)($result['total'] ?? 0);
    
    // Update product rating
    $stmt = $pdo->prepare("UPDATE products SET rating = ? WHERE id = ?");
    $stmt->execute([$avg_rating, $product_id]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Rating submitted successfully!',
        'avg_rating' => $avg_rating,
        'total_ratings' => $total_ratings,
        'user_rating' => $rating
    ]);
    
} catch(PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?>