<?php
// =====================================================
// ORDER DETAILS - CUSTOMER SIDE
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Require login
requireLogin();

$user_id = $_SESSION['user_id'];
$order_id = (int)($_GET['id'] ?? 0);

if ($order_id <= 0) {
    redirect(BASE_URL . '/orders.php');
}

// Get order details
try {
    $stmt = $pdo->prepare("
        SELECT * FROM orders 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$order_id, $user_id]);
    $order = $stmt->fetch();
    
    if (!$order) {
        redirect(BASE_URL . '/orders.php');
    }
} catch(PDOException $e) {
    redirect(BASE_URL . '/orders.php');
}

// Get order items
try {
    $stmt = $pdo->prepare("
        SELECT * FROM order_items 
        WHERE order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll();
} catch(PDOException $e) {
    $order_items = [];
}

// Determine delivery type
$delivery_type = 'Outside Dhaka';
if ($order['delivery_charge'] == 0) {
    $delivery_type = 'Free Delivery';
} elseif (strpos(strtolower($order['city']), 'dhaka') !== false || strpos($order['city'], 'ঢাকা') !== false) {
    $delivery_type = 'Inside Dhaka';
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="section-title mb-0">Order Details</h2>
            <p class="text-muted">Order #<?php echo $order['order_number']; ?></p>
        </div>
        <a href="<?php echo BASE_URL; ?>/orders.php" class="btn btn-outline-custom">
            <i class="bi bi-arrow-left me-2"></i>Back to Orders
        </a>
    </div>
    
    <!-- Order Status -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body p-4">
            <div class="row align-items-center">
                <div class="col-md-3">
                    <h6 class="text-muted mb-0">Order Status</h6>
                    <span class="fs-5 fw-bold"><?php echo getStatusBadge($order['status']); ?></span>
                </div>
                <div class="col-md-3">
                    <h6 class="text-muted mb-0">Order Date</h6>
                    <p class="mb-0"><?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></p>
                </div>
                <div class="col-md-3">
                    <h6 class="text-muted mb-0">Payment Method</h6>
                    <p class="mb-0"><?php echo $order['payment_method']; ?></p>
                </div>
                <div class="col-md-3">
                    <h6 class="text-muted mb-0">Total Amount</h6>
                    <p class="mb-0 fw-bold fs-5"><?php echo formatPrice($order['total']); ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Order Items -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white">
        <h5 class="mb-0">Order Items</h5>
    </div>
    <div class="card-body p-0">
        <?php $item_count = 0; ?>
        <?php foreach ($order_items as $item): ?>
            <?php 
                $item_price = $item['discount_price'] ?? $item['price'];
                $item_total = $item['quantity'] * $item_price;
            ?>
            <div class="cart-item p-3 <?php echo $item_count > 0 ? 'border-top' : ''; ?>">
                <div class="row align-items-center">
                    <div class="col-9 col-md-6">
                        <h6 class="mb-0"><?php echo e($item['product_name']); ?></h6>
                        <small class="text-muted"><?php echo formatPrice($item_price); ?> × <?php echo $item['quantity']; ?></small>
                    </div>
                    <div class="col-3 col-md-6 text-end">
                        <span class="fw-bold"><?php echo formatPrice($item_total); ?></span>
                    </div>
                </div>
            </div>
            <?php $item_count++; ?>
        <?php endforeach; ?>
    </div>
</div>
    
    <div class="row g-4">
        <!-- Order Summary -->
        <div class="col-lg-6">
            <div class="order-summary">
                <h6 class="fw-bold mb-3">Order Summary</h6>
                
                <div class="summary-item">
                    <span>Subtotal</span>
                    <span><?php echo formatPrice($order['subtotal']); ?></span>
                </div>
                
                <?php if ($order['coupon_discount'] > 0): ?>
                    <div class="summary-item text-success">
                        <span>Coupon Discount</span>
                        <span>-<?php echo formatPrice($order['coupon_discount']); ?></span>
                    </div>
                <?php endif; ?>
                
                <div class="summary-item">
                    <span>Delivery Charge</span>
                    <span><?php echo $order['delivery_charge'] > 0 ? formatPrice($order['delivery_charge']) : 'FREE'; ?></span>
                </div>
                
                <div class="summary-item summary-total">
                    <span>Total</span>
                    <span><?php echo formatPrice($order['total']); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Delivery Address -->
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <h6 class="fw-bold mb-3">Delivery Information</h6>
                    
                    <div class="row g-2">
                        <div class="col-12">
                            <strong>Delivery Type:</strong>
                            <?php if ($order['delivery_charge'] == 0): ?>
                                <span class="badge bg-success"><?php echo $delivery_type; ?></span>
                            <?php else: ?>
                                <span class="badge bg-primary"><?php echo $delivery_type; ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="col-12">
                            <strong>Delivery Charge:</strong>
                            <?php echo formatPrice($order['delivery_charge']); ?>
                        </div>
                        <div class="col-12">
                            <strong>City:</strong>
                            <?php echo e($order['city']); ?>
                        </div>
                        <div class="col-12">
                            <strong>Delivery Address:</strong>
                            <p class="mb-0 mt-1"><?php echo nl2br(e($order['address'])); ?></p>
                        </div>
                        <div class="col-12">
                            <strong>Contact:</strong>
                            <p class="mb-0"><?php echo e($order['name']); ?> - <?php echo e($order['phone']); ?></p>
                        </div>
                        <?php if ($order['note']): ?>
                            <div class="col-12">
                                <strong>Order Note:</strong>
                                <p class="mb-0"><?php echo e($order['note']); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>