<?php
// =====================================================
// CHECKOUT
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Require login
requireLogin();

$user_id = $_SESSION['user_id'];
$error = '';

// Get user data
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
} catch(PDOException $e) {
    $user = null;
}

// Get cart items
try {
    $stmt = $pdo->prepare("
        SELECT c.*, p.name, p.price, p.discount_price, p.stock 
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll();
} catch(PDOException $e) {
    $cart_items = [];
}

// Check if cart is empty
if (empty($cart_items)) {
    $_SESSION['error'] = 'Your cart is empty.';
    redirect(BASE_URL . '/cart.php');
}

// Calculate subtotal
$subtotal = 0;
$total_items = 0;
foreach ($cart_items as $item) {
    $price = $item['discount_price'] ?? $item['price'];
    $subtotal += $item['quantity'] * $price;
    $total_items += $item['quantity'];
}

// Process checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $note = trim($_POST['note'] ?? '');
    
    if (empty($name) || empty($phone) || empty($address) || empty($city)) {
        $error = 'Please fill all required fields including delivery address.';
    } else {
        try {
            // Calculate delivery charge based on city
            $city_lower = strtolower($city);
            $is_dhaka = (strpos($city_lower, 'dhaka') !== false || strpos($city_lower, 'ঢাকা') !== false);
            
            if ($is_dhaka) {
                $delivery_charge = DELIVERY_CHARGE_DHAKA;
            } else {
                $delivery_charge = DELIVERY_CHARGE_OUTSIDE;
            }
            
            // Check if free delivery applies
            if ($subtotal >= FREE_DELIVERY_THRESHOLD) {
                $delivery_charge = 0;
            }
            
            $grand_total = $subtotal + $delivery_charge;
            
            // Begin transaction
            $pdo->beginTransaction();
            
            // Check stock for all items
            foreach ($cart_items as $item) {
                if ($item['quantity'] > $item['stock']) {
                    $error = "Not enough stock for {$item['name']}. Available: {$item['stock']}";
                    $pdo->rollBack();
                    break;
                }
            }
            
            if (empty($error)) {
                // Generate order number
                $order_number = generateOrderNumber();
                
                // Insert order
                $stmt = $pdo->prepare("
                    INSERT INTO orders (
                        user_id, order_number, name, phone, address, city, note,
                        subtotal, delivery_charge, total, payment_method, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'COD', 'pending')
                ");
                $stmt->execute([
                    $user_id, $order_number, $name, $phone, $address, $city, $note,
                    $subtotal, $delivery_charge, $grand_total
                ]);
                $order_id = $pdo->lastInsertId();
                
                // Insert order items and update stock
                foreach ($cart_items as $item) {
                    $price = $item['discount_price'] ?? $item['price'];
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO order_items (
                            order_id, product_id, product_name, quantity, price, discount_price
                        ) VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $order_id, $item['product_id'], $item['name'],
                        $item['quantity'], $item['price'], $item['discount_price']
                    ]);
                    
                    // Update stock
                    $new_stock = $item['stock'] - $item['quantity'];
                    $stmt = $pdo->prepare("UPDATE products SET stock = ? WHERE id = ?");
                    $stmt->execute([$new_stock, $item['product_id']]);
                }
                
                // Clear cart
                $stmt = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
                $stmt->execute([$user_id]);
                
                // Commit transaction
                $pdo->commit();
                
                $_SESSION['order_success'] = $order_number;
                redirect(BASE_URL . '/order-details.php?id=' . $order_id);
            }
        } catch(PDOException $e) {
            $pdo->rollBack();
            $error = 'Failed to place order. Please try again.';
        }
    }
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <h2 class="section-title mb-4">Checkout</h2>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo e($error); ?></div>
    <?php endif; ?>
    
    <div class="row g-4">
        <!-- Billing Details -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Billing Details</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="" id="checkoutForm">
                        <div class="row g-3">
                            <div class="col-12">
                                <label for="name" class="form-label">Full Name *</label>
                                <input type="text" class="form-control" id="name" name="name" 
                                       value="<?php echo e($user['name'] ?? ''); ?>" required>
                            </div>
                            
                            <div class="col-12">
                                <label for="phone" class="form-label">Phone Number *</label>
                                <input type="tel" class="form-control" id="phone" name="phone" 
                                       value="<?php echo e($user['phone'] ?? ''); ?>" required>
                            </div>
                            
                            <div class="col-12">
                                <label for="address" class="form-label">Delivery Address *</label>
                                <textarea class="form-control" id="address" name="address" rows="3" 
                                          placeholder="House #, Road #, Area, District" required></textarea>
                            </div>
                            
                            <div class="col-12">
                                <label for="city" class="form-label">City *</label>
                                <select class="form-select" id="city" name="city" required>
                                    <option value="">Select City</option>
                                    <option value="Dhaka">Dhaka</option>
                                    <option value="Chattogram">Chattogram</option>
                                    <option value="Khulna">Khulna</option>
                                    <option value="Rajshahi">Rajshahi</option>
                                    <option value="Sylhet">Sylhet</option>
                                    <option value="Barishal">Barishal</option>
                                    <option value="Rangpur">Rangpur</option>
                                    <option value="Mymensingh">Mymensingh</option>
                                    <option value="Cumilla">Cumilla</option>
                                    <option value="Narayanganj">Narayanganj</option>
                                    <option value="Gazipur">Gazipur</option>
                                    <option value="Other">Other</option>
                                </select>
                                <small class="text-muted">Delivery: Dhaka ৳80 / Outside ৳150 | Free above ৳1000</small>
                            </div>
                            
                            <div class="col-12">
                                <label for="note" class="form-label">Order Notes (Optional)</label>
                                <textarea class="form-control" id="note" name="note" rows="2"></textarea>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary-custom w-100 mt-3 py-2" id="placeOrderBtn">
                            <i class="bi bi-check-circle me-2"></i>Place Order (COD)
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Order Summary -->
        <div class="col-lg-4">
            <div class="order-summary">
                <h6 class="fw-bold mb-3">Order Summary</h6>
                
                <div class="mb-3">
                    <?php foreach ($cart_items as $item): ?>
                        <?php $price = $item['discount_price'] ?? $item['price']; ?>
                        <div class="d-flex justify-content-between small mb-1">
                            <span><?php echo e($item['name']); ?> × <?php echo $item['quantity']; ?></span>
                            <span><?php echo formatPrice($price * $item['quantity']); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <hr>
                
                <div class="summary-item">
                    <span>Subtotal (<?php echo $total_items; ?> items)</span>
                    <span><?php echo formatPrice($subtotal); ?></span>
                </div>
                
                <div class="summary-item">
                    <span>Delivery Charge</span>
                    <span id="deliveryAmount">
                        <?php 
                            $default_delivery = ($subtotal >= FREE_DELIVERY_THRESHOLD) ? 0 : DELIVERY_CHARGE_DHAKA;
                            echo formatPrice($default_delivery);
                        ?>
                    </span>
                </div>
                
                <?php if ($subtotal < FREE_DELIVERY_THRESHOLD): ?>
                    <small class="text-muted d-block mb-2">
                        Add <?php echo formatPrice(FREE_DELIVERY_THRESHOLD - $subtotal); ?> more for free delivery.
                    </small>
                <?php else: ?>
                    <small class="text-success d-block mb-2">
                        <i class="bi bi-check-circle"></i> Free delivery applied!
                    </small>
                <?php endif; ?>
                
                <div class="summary-item summary-total">
                    <span>Grand Total</span>
                    <span id="grandTotal">
                        <?php 
                            $default_total = $subtotal + (($subtotal >= FREE_DELIVERY_THRESHOLD) ? 0 : DELIVERY_CHARGE_DHAKA);
                            echo formatPrice($default_total);
                        ?>
                    </span>
                </div>
                
                <div class="text-center mt-2">
                    <a href="<?php echo BASE_URL; ?>/cart.php" class="text-muted small">
                        <i class="bi bi-arrow-left me-1"></i>Return to Cart
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const citySelect = document.getElementById('city');
    const deliveryAmount = document.getElementById('deliveryAmount');
    const grandTotal = document.getElementById('grandTotal');
    
    if (citySelect) {
        citySelect.addEventListener('change', function() {
            const city = this.value;
            const subtotal = <?php echo $subtotal; ?>;
            const freeThreshold = <?php echo FREE_DELIVERY_THRESHOLD; ?>;
            const dhakaCharge = <?php echo DELIVERY_CHARGE_DHAKA; ?>;
            const outsideCharge = <?php echo DELIVERY_CHARGE_OUTSIDE; ?>;
            
            let deliveryCharge = 0;
            
            if (subtotal >= freeThreshold) {
                deliveryCharge = 0;
            } else if (city === 'Dhaka') {
                deliveryCharge = dhakaCharge;
            } else if (city !== '') {
                deliveryCharge = outsideCharge;
            } else {
                deliveryCharge = dhakaCharge;
            }
            
            if (deliveryAmount) {
                deliveryAmount.textContent = formatPrice(deliveryCharge);
            }
            
            const total = subtotal + deliveryCharge;
            if (grandTotal) {
                grandTotal.textContent = formatPrice(total);
            }
        });
    }
});

function formatPrice(amount) {
    return '৳' + parseFloat(amount).toFixed(2);
}
</script>

<?php include 'includes/footer.php'; ?>