<?php
// =====================================================
// WISHLIST
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Require login
requireLogin();

$user_id = $_SESSION['user_id'];

// Get wishlist items
try {
    $stmt = $pdo->prepare("
        SELECT p.*, c.name as category_name 
        FROM wishlist w 
        JOIN products p ON w.product_id = p.id 
        JOIN categories c ON p.category_id = c.id 
        WHERE w.user_id = ? AND p.status = 1
        ORDER BY w.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $wishlist_items = $stmt->fetchAll();
} catch(PDOException $e) {
    $wishlist_items = [];
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <h2 class="section-title mb-4">My Wishlist</h2>
    
    <?php if (empty($wishlist_items)): ?>
        <div class="text-center py-5">
            <i class="bi bi-heart fs-1 text-muted"></i>
            <h5 class="mt-3">Your wishlist is empty</h5>
            <p class="text-muted">Save your favorite items here.</p>
            <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-primary-custom">Start Shopping</a>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <?php foreach ($wishlist_items as $product): ?>
                <div class="col-6 col-md-4 col-lg-3">
                    <div class="product-card position-relative">
                        <button class="btn btn-sm btn-danger position-absolute top-0 end-0 m-2 wishlist-toggle" 
                                data-product-id="<?php echo $product['id']; ?>" style="z-index: 10;">
                            <i class="bi bi-heart-fill"></i>
                        </button>
                        <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>">
                            <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $product['image'] ?? 'placeholder.jpg'; ?>" 
                                 class="card-img-top" alt="<?php echo e($product['name']); ?>">
                        </a>
                        <div class="card-body">
                            <small class="text-muted"><?php echo e($product['category_name']); ?></small>
                            <h6 class="card-title"><?php echo e($product['name']); ?></h6>
                            <div class="product-price">
                                <?php if ($product['discount_price']): ?>
                                    <span class="text-danger"><?php echo formatPrice($product['discount_price']); ?></span>
                                    <span class="original"><?php echo formatPrice($product['price']); ?></span>
                                <?php else: ?>
                                    <span><?php echo formatPrice($product['price']); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="d-grid gap-2">
                                <button class="btn btn-sm btn-primary-custom add-to-cart-btn" 
                                        data-product-id="<?php echo $product['id']; ?>">
                                    <i class="bi bi-bag me-1"></i>Add to Cart
                                </button>
                                <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>" 
                                   class="btn btn-sm btn-outline-custom">View Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>