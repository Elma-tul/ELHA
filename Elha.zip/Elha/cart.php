<?php
// =====================================================
// SHOPPING CART
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Require login
requireLogin();

$user_id = $_SESSION['user_id'];

// Get cart items
try {
    $stmt = $pdo->prepare("
        SELECT c.*, p.name, p.price, p.discount_price, p.image, p.stock, p.id as product_id
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = ?
    ");
    $stmt->execute([$user_id]);
    $cart_items = $stmt->fetchAll();
} catch(PDOException $e) {
    $cart_items = [];
}

// Calculate totals
$subtotal = 0;
$total_items = 0;
foreach ($cart_items as $item) {
    $price = $item['discount_price'] ?? $item['price'];
    $subtotal += $item['quantity'] * $price;
    $total_items += $item['quantity'];
}

$delivery_charge = ($subtotal >= FREE_DELIVERY_THRESHOLD) ? 0 : DELIVERY_CHARGE_DHAKA;
$grand_total = $subtotal + $delivery_charge;

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <h2 class="section-title mb-4">Shopping Cart</h2>
    
    <?php if (empty($cart_items)): ?>
        <div class="text-center py-5">
            <i class="bi bi-bag fs-1 text-muted"></i>
            <h5 class="mt-3">Your cart is empty</h5>
            <p class="text-muted">Start shopping to add items to your cart.</p>
            <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-primary-custom">Continue Shopping</a>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <!-- Cart Items -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-0">
                        <?php foreach ($cart_items as $index => $item): ?>
                            <?php 
                                $price = $item['discount_price'] ?? $item['price'];
                                $item_total = $item['quantity'] * $price;
                            ?>
                            <div class="cart-item p-3 <?php echo $index > 0 ? 'border-top' : ''; ?>" 
                                 data-product-id="<?php echo $item['product_id']; ?>">
                                <div class="row align-items-center g-3">
                                    <div class="col-3 col-md-2">
                                        <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $item['image'] ?? 'placeholder.jpg'; ?>" 
                                             alt="<?php echo e($item['name']); ?>" class="img-fluid rounded">
                                    </div>
                                    <div class="col-9 col-md-4">
                                        <h6 class="mb-0"><?php echo e($item['name']); ?></h6>
                                        <small class="text-muted"><?php echo formatPrice($price); ?> each</small>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <div class="quantity-control d-flex align-items-center">
                                            <button class="quantity-btn update-cart" data-action="decrease" data-product-id="<?php echo $item['product_id']; ?>">-</button>
                                            <input type="number" class="quantity-input form-control form-control-sm text-center cart-qty" 
                                                   value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $item['stock']; ?>" 
                                                   data-product-id="<?php echo $item['product_id']; ?>" style="width: 50px;">
                                            <button class="quantity-btn update-cart" data-action="increase" data-product-id="<?php echo $item['product_id']; ?>">+</button>
                                        </div>
                                    </div>
                                    <div class="col-3 col-md-2 text-end">
                                        <span class="fw-bold item-total"><?php echo formatPrice($item_total); ?></span>
                                    </div>
                                    <div class="col-3 col-md-1 text-end">
                                        <button class="btn btn-sm btn-danger remove-from-cart" data-product-id="<?php echo $item['product_id']; ?>">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="mt-3">
                    <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-outline-custom">
                        <i class="bi bi-arrow-left me-2"></i>Continue Shopping
                    </a>
                </div>
            </div>
            
            <!-- Order Summary -->
            <div class="col-lg-4">
                <div class="order-summary">
                    <h6 class="fw-bold mb-3">Order Summary</h6>
                    
                    <div class="summary-item">
                        <span>Subtotal (<?php echo $total_items; ?> items)</span>
                        <span id="cart-subtotal"><?php echo formatPrice($subtotal); ?></span>
                    </div>
                    
                    <div class="summary-item">
                        <span>Delivery Charge</span>
                        <span><?php echo $delivery_charge > 0 ? formatPrice($delivery_charge) : 'FREE'; ?></span>
                    </div>
                    
                    <?php if ($subtotal < FREE_DELIVERY_THRESHOLD): ?>
                        <small class="text-muted d-block mb-2">
                            Add <?php echo formatPrice(FREE_DELIVERY_THRESHOLD - $subtotal); ?> more for free delivery.
                        </small>
                    <?php endif; ?>
                    
                    <div class="summary-item summary-total">
                        <span>Grand Total</span>
                        <span id="cart-total"><?php echo formatPrice($grand_total); ?></span>
                    </div>
                    
                    <a href="<?php echo BASE_URL; ?>/checkout.php" class="btn btn-primary-custom w-100 mt-3 py-2">
                        Proceed to Checkout
                    </a>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>