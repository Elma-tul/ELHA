<?php
// =====================================================
// GIFT FINDER
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Get filter parameters
$occasion = $_GET['occasion'] ?? '';
$budget = $_GET['budget'] ?? '';
$recipient = $_GET['recipient'] ?? '';
$search = $_GET['search'] ?? '';

// Build query conditions
$where_conditions = ["p.status = 1", "p.gift_suitable = 1"];
$params = [];

if (!empty($occasion)) {
    $where_conditions[] = "p.occasion = ?";
    $params[] = $occasion;
}

if (!empty($recipient)) {
    $where_conditions[] = "p.recipient = ?";
    $params[] = $recipient;
}

// Budget filter
if (!empty($budget)) {
    switch($budget) {
        case 'under_1000':
            $where_conditions[] = "COALESCE(p.discount_price, p.price) < 1000";
            break;
        case '1000_2000':
            $where_conditions[] = "COALESCE(p.discount_price, p.price) BETWEEN 1000 AND 2000";
            break;
        case '2000_5000':
            $where_conditions[] = "COALESCE(p.discount_price, p.price) BETWEEN 2000 AND 5000";
            break;
        case 'above_5000':
            $where_conditions[] = "COALESCE(p.discount_price, p.price) > 5000";
            break;
    }
}

// Search filter
if (!empty($search)) {
    $where_conditions[] = "(p.name LIKE ? OR p.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$where_clause = implode(" AND ", $where_conditions);

// Get gift products
try {
    $sql = "
        SELECT p.*, c.name as category_name 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE $where_clause 
        ORDER BY p.created_at DESC
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $gift_products = $stmt->fetchAll();
} catch(PDOException $e) {
    $gift_products = [];
}

// Get distinct occasions from products
try {
    $stmt = $pdo->query("
        SELECT DISTINCT occasion 
        FROM products 
        WHERE gift_suitable = 1 AND occasion IS NOT NULL AND occasion != ''
        ORDER BY occasion
    ");
    $occasions = $stmt->fetchAll();
} catch(PDOException $e) {
    $occasions = [];
}

// Get distinct recipients from products
try {
    $stmt = $pdo->query("
        SELECT DISTINCT recipient 
        FROM products 
        WHERE gift_suitable = 1 AND recipient IS NOT NULL AND recipient != ''
        ORDER BY recipient
    ");
    $recipients = $stmt->fetchAll();
} catch(PDOException $e) {
    $recipients = [];
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <div class="row">
        <!-- Sidebar Filters -->
        <div class="col-lg-3 mb-4">
            <div class="card border-0 shadow-sm sticky-top" style="top: 80px;">
                <div class="card-body p-3">
                    <h6 class="fw-bold mb-3"><i class="bi bi-gift me-2"></i>Find a Gift</h6>
                    
                    <form method="GET" action="" id="giftFinderForm">
                        <!-- Search -->
                        <div class="mb-3">
                            <label class="form-label small">Search Gifts</label>
                            <input type="text" class="form-control form-control-sm" name="search" 
                                   placeholder="Search gifts..." 
                                   value="<?php echo e($search); ?>">
                        </div>
                        
                        <!-- Occasion -->
                        <div class="mb-3">
                            <label class="form-label small">Occasion</label>
                            <select class="form-select form-select-sm" name="occasion" onchange="this.form.submit()">
                                <option value="">All Occasions</option>
                                <?php foreach ($occasions as $occ): ?>
                                    <option value="<?php echo $occ['occasion']; ?>" 
                                        <?php echo $occasion === $occ['occasion'] ? 'selected' : ''; ?>>
                                        <?php echo e($occ['occasion']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Recipient -->
                        <div class="mb-3">
                            <label class="form-label small">For</label>
                            <select class="form-select form-select-sm" name="recipient" onchange="this.form.submit()">
                                <option value="">All Recipients</option>
                                <?php foreach ($recipients as $rec): ?>
                                    <option value="<?php echo $rec['recipient']; ?>" 
                                        <?php echo $recipient === $rec['recipient'] ? 'selected' : ''; ?>>
                                        <?php echo e($rec['recipient']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Budget -->
                        <div class="mb-3">
                            <label class="form-label small">Budget</label>
                            <select class="form-select form-select-sm" name="budget" onchange="this.form.submit()">
                                <option value="">Any Budget</option>
                                <option value="under_1000" <?php echo $budget === 'under_1000' ? 'selected' : ''; ?>>Under ৳1,000</option>
                                <option value="1000_2000" <?php echo $budget === '1000_2000' ? 'selected' : ''; ?>>৳1,000 - ৳2,000</option>
                                <option value="2000_5000" <?php echo $budget === '2000_5000' ? 'selected' : ''; ?>>৳2,000 - ৳5,000</option>
                                <option value="above_5000" <?php echo $budget === 'above_5000' ? 'selected' : ''; ?>>Above ৳5,000</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary-custom w-100">Find Gifts</button>
                        <a href="<?php echo BASE_URL; ?>/gift-finder.php" class="btn btn-outline-custom w-100 mt-2">Clear All</a>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Results -->
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h2 class="section-title mb-0">Gift Finder</h2>
                    <p class="text-muted small">
                        <?php echo count($gift_products); ?> gift ideas found
                        <?php if ($occasion): ?>
                            for <strong><?php echo e($occasion); ?></strong>
                        <?php endif; ?>
                        <?php if ($recipient): ?>
                            for <strong><?php echo e($recipient); ?></strong>
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            
            <?php if (empty($gift_products)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-gift fs-1 text-muted"></i>
                    <h5 class="mt-3">No gift ideas found</h5>
                    <p class="text-muted">Try adjusting your filters or search terms.</p>
                    <a href="<?php echo BASE_URL; ?>/gift-finder.php" class="btn btn-primary-custom">Clear Filters</a>
                </div>
            <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($gift_products as $product): ?>
                        <div class="col-6 col-md-4 col-lg-3">
                            <div class="product-card">
                                <div class="position-relative">
                                    <span class="badge bg-primary position-absolute top-0 start-0 m-2">
                                        <i class="bi bi-gift me-1"></i>Gift
                                    </span>
                                    <?php if ($product['discount_price']): ?>
                                        <span class="badge bg-danger position-absolute top-0 end-0 m-2">
                                            -<?php echo round(($product['price'] - $product['discount_price']) / $product['price'] * 100); ?>%
                                        </span>
                                    <?php endif; ?>
                                    <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>">
                                        <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $product['image'] ?? 'placeholder.jpg'; ?>" 
                                             class="card-img-top" alt="<?php echo e($product['name']); ?>">
                                    </a>
                                </div>
                                <div class="card-body">
                                    <small class="text-muted"><?php echo e($product['category_name']); ?></small>
                                    <h6 class="card-title"><?php echo e($product['name']); ?></h6>
                                    <div class="product-price">
                                        <?php if ($product['discount_price']): ?>
                                            <span class="text-danger"><?php echo formatPrice($product['discount_price']); ?></span>
                                            <span class="original"><?php echo formatPrice($product['price']); ?></span>
                                        <?php else: ?>
                                            <span><?php echo formatPrice($product['price']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Gift Tags -->
                                    <div class="mt-2">
                                        <?php if ($product['occasion']): ?>
                                            <span class="badge bg-info small"><?php echo e($product['occasion']); ?></span>
                                        <?php endif; ?>
                                        <?php if ($product['recipient']): ?>
                                            <span class="badge bg-secondary small">For <?php echo e($product['recipient']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="d-grid gap-2 mt-2">
                                        <button class="btn btn-sm btn-primary-custom add-to-cart-btn" 
                                                data-product-id="<?php echo $product['id']; ?>">
                                            <i class="bi bi-bag me-1"></i>Add to Cart
                                        </button>
                                        <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>" 
                                           class="btn btn-sm btn-outline-custom">View Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>