<?php
// =====================================================
// HOMEPAGE
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Get featured products
try {
    $stmt = $pdo->prepare("
        SELECT p.*, c.name as category_name 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE p.status = 1 
        ORDER BY p.created_at DESC 
        LIMIT 8
    ");
    $stmt->execute();
    $featured_products = $stmt->fetchAll();
} catch(PDOException $e) {
    $featured_products = [];
}

// Get weekly deals
try {
    $stmt = $pdo->prepare("
        SELECT p.*, c.name as category_name, wd.discount_percentage 
        FROM weekly_deals wd 
        JOIN products p ON wd.product_id = p.id 
        JOIN categories c ON p.category_id = c.id 
        WHERE wd.is_active = 1 
        AND wd.start_date <= CURDATE() 
        AND wd.end_date >= CURDATE() 
        AND p.status = 1
        LIMIT 4
    ");
    $stmt->execute();
    $weekly_deals = $stmt->fetchAll();
} catch(PDOException $e) {
    $weekly_deals = [];
}

// Get categories for display
try {
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
    $categories = $stmt->fetchAll();
} catch(PDOException $e) {
    $categories = [];
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<main>
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <p class="text-uppercase text-muted small fw-bold mb-2">Discover Your Beauty</p>
                    <h1 class="hero-title">Personalized Beauty & Fashion</h1>
                    <p class="hero-subtitle">Find products that match your style and preferences with ELHA's smart recommendation system.</p>
                    <div class="mt-4">
                        <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-primary-custom me-3">Shop Now</a>
                        <?php if (!isLoggedIn()): ?>
                            <a href="<?php echo BASE_URL; ?>/register.php" class="btn btn-outline-custom">Join ELHA</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <img src="<?php echo BASE_URL; ?>/assets/images/logo.png" alt="E L H A" class="img-fluid" style="max-height: 200px;">
                </div>
            </div>
        </div>
    </section>
    
    <!-- Categories Section -->
    <section class="container mb-5">
        <div class="text-center mb-4">
            <h2 class="section-title">Shop by Category</h2>
            <p class="section-subtitle">Find exactly what you're looking for</p>
        </div>
        <div class="row g-3">
            <?php foreach ($categories as $cat): ?>
                <div class="col-6 col-md-3">
                    <a href="<?php echo BASE_URL; ?>/shop.php?category=<?php echo $cat['slug']; ?>" class="text-decoration-none">
                        <div class="card text-center border-0 shadow-sm hover-shadow">
                            <div class="card-body py-4">
                                <h6 class="mb-0"><?php echo e($cat['name']); ?></h6>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    
    <!-- Weekly Deals -->
    <?php if (!empty($weekly_deals)): ?>
        <section class="container mb-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 class="section-title">Deal of the Week</h2>
                    <p class="section-subtitle">Limited time offers</p>
                </div>
                <a href="<?php echo BASE_URL; ?>/shop.php?deal=1" class="btn btn-outline-custom">View All</a>
            </div>
            <div class="row g-4">
                <?php foreach ($weekly_deals as $product): ?>
                    <div class="col-6 col-md-3">
                        <div class="product-card">
                            <div class="position-relative">
                                <?php if ($product['discount_percentage']): ?>
                                    <span class="badge bg-danger position-absolute top-0 end-0 m-2">-<?php echo $product['discount_percentage']; ?>%</span>
                                <?php endif; ?>
                                <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $product['image'] ?? 'placeholder.jpg'; ?>" 
                                     class="card-img-top" alt="<?php echo e($product['name']); ?>">
                            </div>
                            <div class="card-body">
                                <small class="text-muted"><?php echo e($product['category_name']); ?></small>
                                <h6 class="card-title"><?php echo e($product['name']); ?></h6>
                                <div class="product-price">
                                    <?php if ($product['discount_percentage']): ?>
                                        <?php 
                                            $discounted_price = $product['price'] * (1 - $product['discount_percentage'] / 100);
                                        ?>
                                        <span class="text-danger"><?php echo formatPrice($discounted_price); ?></span>
                                        <span class="original"><?php echo formatPrice($product['price']); ?></span>
                                    <?php else: ?>
                                        <span><?php echo formatPrice($product['price']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-primary-custom w-100 mt-2">View Product</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>
    
    <!-- Featured Products -->
    <section class="container mb-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="section-title">Featured Products</h2>
                <p class="section-subtitle">New arrivals and best sellers</p>
            </div>
            <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-outline-custom">View All</a>
        </div>
        <div class="row g-4">
            <?php foreach ($featured_products as $product): ?>
                <div class="col-6 col-md-3">
                    <div class="product-card">
                        <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $product['image'] ?? 'placeholder.jpg'; ?>" 
                             class="card-img-top" alt="<?php echo e($product['name']); ?>">
                        <div class="card-body">
                            <small class="text-muted"><?php echo e($product['category_name']); ?></small>
                            <h6 class="card-title"><?php echo e($product['name']); ?></h6>
                            <div class="product-price">
                                <?php if ($product['discount_price']): ?>
                                    <span class="text-danger"><?php echo formatPrice($product['discount_price']); ?></span>
                                    <span class="original"><?php echo formatPrice($product['price']); ?></span>
                                <?php else: ?>
                                    <span><?php echo formatPrice($product['price']); ?></span>
                                <?php endif; ?>
                            </div>
                            <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-primary-custom w-100 mt-2">View Product</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
    
    <!-- Features Banner -->
    <section class="container mb-5">
        <div class="row g-4">
            <div class="col-md-3 col-6">
                <div class="text-center p-3 bg-white rounded shadow-sm">
                    <i class="bi bi-truck fs-2 text-primary-custom"></i>
                    <h6 class="mt-2">Free Delivery</h6>
                    <small class="text-muted">On orders above ৳1000</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="text-center p-3 bg-white rounded shadow-sm">
                    <i class="bi bi-arrow-repeat fs-2 text-primary-custom"></i>
                    <h6 class="mt-2">Easy Returns</h6>
                    <small class="text-muted">7-day return policy</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="text-center p-3 bg-white rounded shadow-sm">
                    <i class="bi bi-shield-check fs-2 text-primary-custom"></i>
                    <h6 class="mt-2">Secure Shopping</h6>
                    <small class="text-muted">Safe & secure checkout</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="text-center p-3 bg-white rounded shadow-sm">
                    <i class="bi bi-star fs-2 text-primary-custom"></i>
                    <h6 class="mt-2">Personalized</h6>
                    <small class="text-muted">Smart recommendations</small>
                </div>
            </div>
        </div>
    </section>
</main>

<?php include 'includes/footer.php'; ?>