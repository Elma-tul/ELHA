<?php
// =====================================================
// ORDER TRACKING
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Require login
requireLogin();

$user_id = $_SESSION['user_id'];
$order_id = (int)($_GET['id'] ?? 0);

if ($order_id <= 0) {
    redirect(BASE_URL . '/orders.php');
}

// Get order details
try {
    $stmt = $pdo->prepare("
        SELECT * FROM orders 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$order_id, $user_id]);
    $order = $stmt->fetch();
    
    if (!$order) {
        redirect(BASE_URL . '/orders.php');
    }
} catch(PDOException $e) {
    redirect(BASE_URL . '/orders.php');
}

$statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'];
$status_labels = [
    'pending' => 'Order Placed',
    'confirmed' => 'Confirmed',
    'processing' => 'Processing',
    'shipped' => 'Shipped',
    'delivered' => 'Delivered',
    'cancelled' => 'Cancelled'
];
$status_icons = [
    'pending' => 'bi-clock-history',
    'confirmed' => 'bi-check-circle',
    'processing' => 'bi-arrow-repeat',
    'shipped' => 'bi-truck',
    'delivered' => 'bi-check2-circle',
    'cancelled' => 'bi-x-circle'
];
$status_colors = [
    'pending' => '#f39c12',
    'confirmed' => '#3498db',
    'processing' => '#9b59b6',
    'shipped' => '#2980b9',
    'delivered' => '#27ae60',
    'cancelled' => '#e74c3c'
];

$current_status = $order['status'];
$current_index = array_search($current_status, $statuses);

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="text-center mb-4">
                <h2 class="section-title">Track Your Order</h2>
                <p class="text-muted">Order #<?php echo $order['order_number']; ?></p>
            </div>
            
            <div class="card border-0 shadow-lg">
                <div class="card-body p-4 p-md-5">
                    <!-- Status Progress -->
                    <div class="position-relative" style="padding: 20px 0;">
                        <?php if ($current_status === 'cancelled'): ?>
                            <div class="text-center py-4">
                                <i class="bi bi-x-circle fs-1 text-danger"></i>
                                <h4 class="text-danger">Order Cancelled</h4>
                                <p class="text-muted">This order has been cancelled.</p>
                            </div>
                        <?php else: ?>
                            <!-- Progress Bar -->
                            <div class="progress mb-4" style="height: 8px;">
                                <?php 
                                    $progress = ($current_index / (count($statuses) - 2)) * 100;
                                ?>
                                <div class="progress-bar bg-success" role="progressbar" 
                                     style="width: <?php echo $progress; ?>%;" 
                                     aria-valuenow="<?php echo $progress; ?>" 
                                     aria-valuemin="0" aria-valuemax="100">
                                </div>
                            </div>
                            
                            <!-- Status Steps -->
                            <div class="row text-center">
                                <?php foreach ($statuses as $index => $status): ?>
                                    <?php if ($status === 'cancelled') continue; ?>
                                    <?php 
                                        $is_completed = $index <= $current_index;
                                        $is_current = $index === $current_index;
                                    ?>
                                    <div class="col">
                                        <div class="position-relative">
                                            <div class="rounded-circle d-inline-flex align-items-center justify-content-center 
                                                        <?php echo $is_completed ? 'bg-success' : 'bg-secondary'; ?> 
                                                        text-white" 
                                                 style="width: 40px; height: 40px; font-size: 1.2rem; margin: 0 auto;">
                                                <?php if ($is_completed): ?>
                                                    <i class="bi bi-check-lg"></i>
                                                <?php else: ?>
                                                    <i class="<?php echo $status_icons[$status]; ?>"></i>
                                                <?php endif; ?>
                                            </div>
                                            <div class="mt-2">
                                                <small class="d-block fw-bold <?php echo $is_completed ? 'text-success' : 'text-muted'; ?>">
                                                    <?php echo $status_labels[$status]; ?>
                                                </small>
                                                <?php if ($is_current): ?>
                                                    <span class="badge bg-primary mt-1">Current</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <hr>
                    
                    <!-- Order Info -->
                    <div class="row g-3 mt-3">
                        <div class="col-md-6">
                            <h6 class="text-muted mb-1">Order Date</h6>
                            <p class="fw-bold"><?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted mb-1">Total Amount</h6>
                            <p class="fw-bold"><?php echo formatPrice($order['total']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted mb-1">Payment Method</h6>
                            <p class="fw-bold"><?php echo $order['payment_method']; ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted mb-1">Delivery Address</h6>
                            <p class="mb-0"><?php echo e($order['address']); ?></p>
                            <p><?php echo e($order['city']); ?></p>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="<?php echo BASE_URL; ?>/order-details.php?id=<?php echo $order['id']; ?>" 
                           class="btn btn-primary-custom">
                            View Full Order Details
                        </a>
                        <a href="<?php echo BASE_URL; ?>/orders.php" class="btn btn-outline-custom ms-2">
                            Back to Orders
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>