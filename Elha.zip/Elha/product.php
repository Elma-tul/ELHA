<?php
// =====================================================
// PRODUCT DETAILS
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

$product_id = (int)($_GET['id'] ?? 0);

if ($product_id <= 0) {
    redirect(BASE_URL . '/shop.php');
}

// Get product details
try {
    $stmt = $pdo->prepare("
        SELECT p.*, c.name as category_name, c.slug as category_slug 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE p.id = ? AND p.status = 1
    ");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    
    if (!$product) {
        redirect(BASE_URL . '/shop.php');
    }
} catch(PDOException $e) {
    redirect(BASE_URL . '/shop.php');
}

// Check if in wishlist
$in_wishlist = false;
if (isLoggedIn()) {
    $in_wishlist = isInWishlist($pdo, $_SESSION['user_id'], $product_id);
}

// Get related products (same category)
try {
    $stmt = $pdo->prepare("
        SELECT p.*, c.name as category_name 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE p.category_id = ? AND p.id != ? AND p.status = 1 
        LIMIT 4
    ");
    $stmt->execute([$product['category_id'], $product_id]);
    $related_products = $stmt->fetchAll();
} catch(PDOException $e) {
    $related_products = [];
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>/shop.php">Shop</a></li>
            <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>/shop.php?category=<?php echo $product['category_slug']; ?>"><?php echo e($product['category_name']); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($product['name']); ?></li>
        </ol>
    </nav>
    
    <div class="row g-4">
        <!-- Product Image -->
        <div class="col-md-5">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-3 text-center">
                    <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $product['image'] ?? 'placeholder.jpg'; ?>" 
                         alt="<?php echo e($product['name']); ?>" 
                         class="img-fluid" style="max-height: 400px; object-fit: contain;">
                </div>
            </div>
        </div>
        
        <!-- Product Info -->
        <div class="col-md-7">
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <small class="text-muted"><?php echo e($product['category_name']); ?></small>
                    <h2 class="mb-2" style="font-family: 'Playfair Display', serif;"><?php echo e($product['name']); ?></h2>
                    
                    <!-- Price -->
                    <div class="mb-3">
                        <?php if ($product['discount_price']): ?>
                            <span class="fs-3 fw-bold text-danger"><?php echo formatPrice($product['discount_price']); ?></span>
                            <span class="text-decoration-line-through text-muted fs-5 ms-2"><?php echo formatPrice($product['price']); ?></span>
                            <span class="badge bg-success ms-2">Save <?php echo round(($product['price'] - $product['discount_price']) / $product['price'] * 100); ?>%</span>
                        <?php else: ?>
                            <span class="fs-3 fw-bold"><?php echo formatPrice($product['price']); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Stock -->
                    <div class="mb-3">
                        <?php if ($product['stock'] > 0): ?>
                            <span class="badge bg-success">In Stock</span>
                            <span class="text-muted small ms-2"><?php echo $product['stock']; ?> units available</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Out of Stock</span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Description -->
                    <div class="mb-3">
                        <p><?php echo nl2br(e($product['description'])); ?></p>
                    </div>
                    
                    <!-- Actions -->
                    <?php if ($product['stock'] > 0): ?>
                        <div class="d-flex gap-2 flex-wrap">
                            <div class="quantity-control d-flex align-items-center me-2">
                                <button class="quantity-btn" data-action="decrease">-</button>
                                <input type="number" class="quantity-input form-control form-control-sm text-center" 
                                       value="1" min="1" max="<?php echo $product['stock']; ?>" 
                                       style="width: 60px;">
                                <button class="quantity-btn" data-action="increase">+</button>
                            </div>
                            
                            <button class="btn btn-primary-custom add-to-cart-btn" 
                                    data-product-id="<?php echo $product['id']; ?>">
                                <i class="bi bi-bag me-2"></i>Add to Cart
                            </button>
                            
                            <button class="btn btn-outline-custom wishlist-toggle <?php echo $in_wishlist ? 'text-danger' : ''; ?>" 
                                    data-product-id="<?php echo $product['id']; ?>">
                                <i class="bi <?php echo $in_wishlist ? 'bi-heart-fill' : 'bi-heart'; ?>"></i>
                                <span class="d-none d-md-inline">Wishlist</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Product Meta -->
                    <hr>
                    <div class="row small text-muted">
                        <div class="col-6">
                            <i class="bi bi-tag me-1"></i> Category: <?php echo e($product['category_name']); ?>
                        </div>
                        <div class="col-6">
                            <i class="bi bi-clock me-1"></i> Added: <?php echo date('M d, Y', strtotime($product['created_at'])); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Complete the Look Button -->
    <?php
    // Check if this product has matches
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM product_matches WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $has_matches = $stmt->fetchColumn() > 0;
    } catch(PDOException $e) {
        $has_matches = false;
    }
    ?>

    <?php if ($has_matches): ?>
        <div class="mt-3">
            <a href="<?php echo BASE_URL; ?>/complete-look.php?product_id=<?php echo $product['id']; ?>" 
            class="btn btn-outline-custom w-100">
                <i class="bi bi-grid-3x3-gap me-2"></i>Complete the Look
                <small class="text-muted">(See matching items)</small>
            </a>
        </div>
    <?php endif; ?>
    
    <!-- Related Products -->
    <?php if (!empty($related_products)): ?>
        <section class="mt-5">
            <h4 class="section-title">You May Also Like</h4>
            <div class="row g-4">
                <?php foreach ($related_products as $related): ?>
                    <div class="col-6 col-md-3">
                        <div class="product-card">
                            <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $related['id']; ?>">
                                <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $related['image'] ?? 'placeholder.jpg'; ?>" 
                                     class="card-img-top" alt="<?php echo e($related['name']); ?>">
                            </a>
                            <div class="card-body">
                                <small class="text-muted"><?php echo e($related['category_name']); ?></small>
                                <h6 class="card-title"><?php echo e($related['name']); ?></h6>
                                <div class="product-price">
                                    <?php if ($related['discount_price']): ?>
                                        <span class="text-danger"><?php echo formatPrice($related['discount_price']); ?></span>
                                        <span class="original"><?php echo formatPrice($related['price']); ?></span>
                                    <?php else: ?>
                                        <span><?php echo formatPrice($related['price']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $related['id']; ?>" 
                                   class="btn btn-sm btn-primary-custom w-100 mt-2">View</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>