<?php
// Check if user is logged in
$is_logged_in = isset($_SESSION['user_id']);
$user_name = $_SESSION['user_name'] ?? 'Guest';

// Make $pdo available in this scope
global $pdo;

// Check for order success message
if (isset($_SESSION['order_success'])) {
    $order_success = $_SESSION['order_success'];
    unset($_SESSION['order_success']);
} else {
    $order_success = null;
}
?>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="<?php echo BASE_URL; ?>/index.php">
            <span class="brand-logo">ELHA</span>
            <span class="brand-tagline">Beauty & Fashion</span>
        </a>
        
        <!-- Mobile Toggle -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Navbar Links -->
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo BASE_URL; ?>/index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo BASE_URL; ?>/shop.php">Shop</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="categoriesDropdown" role="button" data-bs-toggle="dropdown">
                        Categories
                    </a>
                    <ul class="dropdown-menu">
                        <?php
                        // Fetch categories from database
                        try {
                            if ($pdo) {
                                $stmt = $pdo->query("SELECT * FROM categories WHERE id IN (SELECT DISTINCT category_id FROM products WHERE status = 1)");
                                while ($cat = $stmt->fetch()) {
                                    echo '<li><a class="dropdown-item" href="' . BASE_URL . '/shop.php?category=' . $cat['slug'] . '">' . htmlspecialchars($cat['name']) . '</a></li>';
                                }
                            }
                        } catch(PDOException $e) {
                            // Silent fail
                        }
                        ?>
                    </ul>
                </li>
                <?php if ($is_logged_in): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/recommendations.php">
                            <i class="bi bi-star"></i> Recommendations
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/complete-look.php">
                            <i class="bi bi-grid-3x3-gap"></i> Complete the Look
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo BASE_URL; ?>/gift-finder.php">
                            <i class="bi bi-gift"></i> Gift Finder
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
            
            <!-- Right Side Icons -->
            <div class="d-flex align-items-center gap-2">
                <?php if ($is_logged_in): ?>
                    <!-- Wishlist -->
                    <a href="<?php echo BASE_URL; ?>/wishlist.php" class="nav-icon position-relative">
                        <i class="bi bi-heart fs-5"></i>
                        <?php
                        // Get wishlist count
                        try {
                            if ($pdo) {
                                $stmt = $pdo->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = ?");
                                $stmt->execute([$_SESSION['user_id']]);
                                $wishlist_count = $stmt->fetchColumn();
                                if ($wishlist_count > 0) {
                                    echo '<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">' . $wishlist_count . '</span>';
                                }
                            }
                        } catch(PDOException $e) {}
                        ?>
                    </a>
                    
                    <!-- Cart -->
                    <a href="<?php echo BASE_URL; ?>/cart.php" class="nav-icon position-relative">
                        <i class="bi bi-bag fs-5"></i>
                        <?php
                        // Get cart count
                        try {
                            if ($pdo) {
                                $stmt = $pdo->prepare("SELECT SUM(quantity) FROM cart WHERE user_id = ?");
                                $stmt->execute([$_SESSION['user_id']]);
                                $cart_count = $stmt->fetchColumn();
                                if ($cart_count > 0) {
                                    echo '<span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary">' . $cart_count . '</span>';
                                }
                            }
                        } catch(PDOException $e) {}
                        ?>
                    </a>
                    
                    <!-- Profile Dropdown -->
                    <div class="dropdown">
                        <a href="#" class="nav-icon dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle fs-4"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><span class="dropdown-item-text fw-bold"><?php echo htmlspecialchars($user_name); ?></span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/profile.php"><i class="bi bi-person me-2"></i>My Profile</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/orders.php"><i class="bi bi-box me-2"></i>My Orders</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>/wishlist.php"><i class="bi bi-heart me-2"></i>Wishlist</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?php echo BASE_URL; ?>/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="<?php echo BASE_URL; ?>/login.php" class="btn btn-outline-dark btn-sm">Login</a>
                    <a href="<?php echo BASE_URL; ?>/register.php" class="btn btn-dark btn-sm">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<?php if ($order_success): ?>
    <div class="container mt-3">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <strong>Order placed successfully!</strong> Your order #<?php echo $order_success; ?> has been confirmed.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    </div>
<?php endif; ?>