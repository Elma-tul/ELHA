<?php
// =====================================================
// HELPER FUNCTIONS
// =====================================================

/**
 * Redirect to a URL
 */
function redirect($url) {
    header("Location: " . $url);
    exit();
}

/**
 * Sanitize input
 */
function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Escape output for HTML
 */
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Format price in INR
 */
function formatPrice($amount) {
    return '৳' . number_format($amount, 2);
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Get logged in user ID
 */
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get user name
 */
function getUserName() {
    return $_SESSION['user_name'] ?? 'Guest';
}

/**
 * Get cart total items
 */
function getCartCount($pdo, $user_id) {
    try {
        $stmt = $pdo->prepare("SELECT SUM(quantity) FROM cart WHERE user_id = ?");
        $stmt->execute([$user_id]);
        return (int)$stmt->fetchColumn();
    } catch(PDOException $e) {
        return 0;
    }
}

/**
 * Get wishlist count
 */
function getWishlistCount($pdo, $user_id) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = ?");
        $stmt->execute([$user_id]);
        return (int)$stmt->fetchColumn();
    } catch(PDOException $e) {
        return 0;
    }
}

/**
 * Get cart subtotal
 */
function getCartSubtotal($pdo, $user_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT SUM(c.quantity * COALESCE(p.discount_price, p.price)) 
            FROM cart c 
            JOIN products p ON c.product_id = p.id 
            WHERE c.user_id = ?
        ");
        $stmt->execute([$user_id]);
        return (float)$stmt->fetchColumn();
    } catch(PDOException $e) {
        return 0;
    }
}

/**
 * Generate order number
 */
function generateOrderNumber() {
    return 'ELH-' . strtoupper(uniqid());
}

/**
 * Check if product is in wishlist
 */
function isInWishlist($pdo, $user_id, $product_id) {
    try {
        $stmt = $pdo->prepare("SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?");
        $stmt->execute([$user_id, $product_id]);
        return $stmt->fetch() ? true : false;
    } catch(PDOException $e) {
        return false;
    }
}

/**
 * Get product rating
 */
function getProductRating($pdo, $product_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT AVG(rating) as avg_rating, COUNT(*) as total 
            FROM reviews 
            WHERE product_id = ?
        ");
        $stmt->execute([$product_id]);
        return $stmt->fetch();
    } catch(PDOException $e) {
        return ['avg_rating' => 0, 'total' => 0];
    }
}




/**
 * Generate CSRF token
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// =====================================================
// ORDER FUNCTIONS
// =====================================================

/**
 * Get order status badge HTML
 */
function getStatusBadge($status) {
    $statuses = [
        'pending' => ['label' => 'Pending', 'class' => 'warning'],
        'confirmed' => ['label' => 'Confirmed', 'class' => 'info'],
        'processing' => ['label' => 'Processing', 'class' => 'primary'],
        'shipped' => ['label' => 'Shipped', 'class' => 'info'],
        'delivered' => ['label' => 'Delivered', 'class' => 'success'],
        'cancelled' => ['label' => 'Cancelled', 'class' => 'danger']
    ];
    
    $status_info = $statuses[$status] ?? ['label' => ucfirst($status), 'class' => 'secondary'];
    return '<span class="badge bg-' . $status_info['class'] . '">' . $status_info['label'] . '</span>';
}

/**
 * Get order status label
 */
function getStatusLabel($status) {
    $labels = [
        'pending' => 'Order Placed',
        'confirmed' => 'Confirmed',
        'processing' => 'Processing',
        'shipped' => 'Shipped',
        'delivered' => 'Delivered',
        'cancelled' => 'Cancelled'
    ];
    return $labels[$status] ?? ucfirst($status);
}

/**
 * Get order status icon
 */
function getStatusIcon($status) {
    $icons = [
        'pending' => 'bi-clock-history',
        'confirmed' => 'bi-check-circle',
        'processing' => 'bi-arrow-repeat',
        'shipped' => 'bi-truck',
        'delivered' => 'bi-check2-circle',
        'cancelled' => 'bi-x-circle'
    ];
    return $icons[$status] ?? 'bi-question-circle';
}

/**
 * Check if user can review a product
 */
function canReview($pdo, $user_id, $product_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT id FROM orders o 
            JOIN order_items oi ON o.id = oi.order_id 
            WHERE o.user_id = ? AND oi.product_id = ? 
            AND o.status = 'delivered'
            LIMIT 1
        ");
        $stmt->execute([$user_id, $product_id]);
        return $stmt->fetch() ? true : false;
    } catch(PDOException $e) {
        return false;
    }
}
?>