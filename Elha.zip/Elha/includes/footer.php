<!-- Footer -->
<footer class="footer mt-auto py-5">
    <div class="container">
        <div class="row g-4">
            <!-- Brand Column -->
            <div class="col-lg-4">
                <h3 class="footer-brand">ELHA</h3>
                <p class="text-muted">Personalized beauty and fashion for every individual. Discover products that match your unique style and needs.</p>
                <div class="social-links mt-3">
                    <a href="#"><i class="bi bi-facebook"></i></a>
                    <a href="#"><i class="bi bi-instagram"></i></a>
                    <a href="#"><i class="bi bi-twitter"></i></a>
                    <a href="#"><i class="bi bi-youtube"></i></a>
                </div>
            </div>
            
            <!-- Quick Links -->
            <div class="col-lg-2 col-md-4">
                <h6 class="footer-heading">Quick Links</h6>
                <ul class="list-unstyled">
                    <li><a href="<?php echo BASE_URL; ?>/index.php">Home</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/shop.php">Shop</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/cart.php">Cart</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/contact.php">Contact</a></li>
                </ul>
            </div>
            
            <!-- Categories -->
            <div class="col-lg-2 col-md-4">
                <h6 class="footer-heading">Categories</h6>
                <ul class="list-unstyled">
                    <?php
                    global $pdo;
                    try {
                        if ($pdo) {
                            $stmt = $pdo->query("SELECT * FROM categories");
                            while ($cat = $stmt->fetch()) {
                                echo '<li><a href="' . BASE_URL . '/shop.php?category=' . $cat['slug'] . '">' . htmlspecialchars($cat['name']) . '</a></li>';
                            }
                        }
                    } catch(PDOException $e) {}
                    ?>
                </ul>
            </div>
            
            <!-- Features -->
            <div class="col-lg-2 col-md-4">
                <h6 class="footer-heading">Features</h6>
                <ul class="list-unstyled">
                    <li><a href="<?php echo BASE_URL; ?>/recommendations.php">Recommendations</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/gift-finder.php">Gift Finder</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/complete-look.php">Complete the Look</a></li>
                </ul>
            </div>
            
            <!-- Contact -->
            <div class="col-lg-2 col-md-4">
                <h6 class="footer-heading">Contact</h6>
                <ul class="list-unstyled">
                    <li><i class="bi bi-envelope"></i> 0.00.e.l.h.a.00.0@gmail.com </li>
                    <li><i class="bi bi-phone"></i> 01613094666</li>
                    <li><i class="bi bi-geo-alt"></i> Dhaka, Bangladesh</li>
                </ul>
            </div>
        </div>
        
        <hr class="mt-4">
        <div class="text-center text-muted small">
            &copy; <?php echo date('Y'); ?> ELHA. All rights reserved.
        </div>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script src="<?php echo BASE_URL; ?>/assets/js/script.js"></script>
</body>
</html>