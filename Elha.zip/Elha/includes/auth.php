<?php
// =====================================================
// AUTHENTICATION HELPER
// =====================================================

/**
 * Require user login
 */
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['error'] = 'Please login to access this page.';
        redirect(BASE_URL . '/login.php');
        exit();
    }
}

/**
 * Require admin login
 */
function requireAdmin() {
    if (!isset($_SESSION['admin_id'])) {
        $_SESSION['error'] = 'Please login as admin to access this page.';
        redirect(BASE_URL . '/admin/login.php');
        exit();
    }
}

/**
 * Check if admin is logged in
 */
function isAdmin() {
    return isset($_SESSION['admin_id']);
}

/**
 * Login user
 */
function loginUser($pdo, $email, $password) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            return true;
        }
        return false;
    } catch(PDOException $e) {
        return false;
    }
}

/**
 * Login admin
 */
function loginAdmin($pdo, $email, $password) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();
        
        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            $_SESSION['admin_email'] = $admin['email'];
            return true;
        }
        return false;
    } catch(PDOException $e) {
        return false;
    }
}



/**
 * Logout user
 */
function logoutUser() {
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Clear all session variables
    $_SESSION = array();
    
    // Destroy the session
    session_destroy();
}

/**
 * Logout admin
 */
function logoutAdmin() {
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Clear all session variables
    $_SESSION = array();
    
    // Destroy the session
    session_destroy();
}



function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Check if email exists
 */
function emailExists($pdo, $email) {
    try {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch() ? true : false;
    } catch(PDOException $e) {
        return false;
    }
}
?>