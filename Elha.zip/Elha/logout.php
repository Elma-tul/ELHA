<?php
// =====================================================
// LOGOUT
// =====================================================

// Start session first
session_start();

require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Check if admin logout
if (isset($_GET['admin'])) {
    logoutAdmin();
    redirect(BASE_URL . '/admin/login.php');
} else {
    logoutUser();
    redirect(BASE_URL . '/login.php');
}
?>