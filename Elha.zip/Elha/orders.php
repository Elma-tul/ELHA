<?php
// =====================================================
// ORDER HISTORY
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Require login
requireLogin();

$user_id = $_SESSION['user_id'];

// Get all orders
try {
    $stmt = $pdo->prepare("
        SELECT * FROM orders 
        WHERE user_id = ? 
        ORDER BY created_at DESC
    ");
    $stmt->execute([$user_id]);
    $orders = $stmt->fetchAll();
} catch(PDOException $e) {
    $orders = [];
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <h2 class="section-title mb-4">My Orders</h2>
    
    <?php if (empty($orders)): ?>
        <div class="text-center py-5">
            <i class="bi bi-box fs-1 text-muted"></i>
            <h5 class="mt-3">No orders yet</h5>
            <p class="text-muted">Start shopping to place your first order.</p>
            <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-primary-custom">Start Shopping</a>
        </div>
    <?php else: ?>
        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>Order #</th>
                                <th>Date</th>
                                <th>Items</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                                <?php 
                                    // Get item count
                                    $stmt = $pdo->prepare("SELECT SUM(quantity) FROM order_items WHERE order_id = ?");
                                    $stmt->execute([$order['id']]);
                                    $item_count = (int)$stmt->fetchColumn();
                                ?>
                                <tr>
                                    <td>
                                        <span class="fw-bold">#<?php echo $order['order_number']; ?></span>
                                    </td>
                                    <td><?php echo date('d M Y', strtotime($order['created_at'])); ?></td>
                                    <td><?php echo $item_count; ?> items</td>
                                    <td class="fw-bold"><?php echo formatPrice($order['total']); ?></td>
                                    <td><?php echo getStatusBadge($order['status']); ?></td>
                                    <td>
                                        <a href="<?php echo BASE_URL; ?>/order-details.php?id=<?php echo $order['id']; ?>" 
                                           class="btn btn-sm btn-primary-custom">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>