<?php
// =====================================================
// SITE CONFIGURATION
// =====================================================

// Base URL
define('BASE_URL', 'http://localhost/Elha');

// Site name
define('SITE_NAME', 'ELHA');

// Admin email
define('ADMIN_EMAIL', 'admin@elha.com');

// Delivery charges (in BDT)
define('DELIVERY_CHARGE_DHAKA', 80);      // Inside Dhaka
define('DELIVERY_CHARGE_OUTSIDE', 150);   // Outside Dhaka

// Free delivery threshold (in BDT)
define('FREE_DELIVERY_THRESHOLD', 1000);
?>