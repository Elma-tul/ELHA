<?php
// =====================================================
// PRODUCT RECOMMENDATIONS - CONNECTED TO ADMIN RULES
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Require login
requireLogin();

$selected_skin = $_GET['skin_type'] ?? '';
$selected_concern = $_GET['concern'] ?? '';
$recommendations = [];
$recommendation_reason = '';

$skin_labels = [
    'oily' => 'Oily Skin',
    'dry' => 'Dry Skin',
    'combination' => 'Combination Skin',
    'normal' => 'Normal Skin'
];

$concern_labels = [
    'acne' => 'Acne',
    'dark spots' => 'Dark Spots',
    'dryness' => 'Dryness',
    'sensitive' => 'Sensitive Skin',
    'dullness' => 'Dullness',
    'uneven tone' => 'Uneven Skin Tone'
];

// If skin type and concern are selected, get recommendations from admin rules
if (!empty($selected_skin) && !empty($selected_concern)) {
    try {
        // First, find the recommendation rule that matches
        $stmt = $pdo->prepare("
            SELECT * FROM recommendation_rules 
            WHERE skin_type = ? AND concern = ?
        ");
        $stmt->execute([$selected_skin, $selected_concern]);
        $rule = $stmt->fetch();
        
        if ($rule) {
            $recommendation_reason = $rule['description'];
            
            // Get products associated with this rule
            $stmt = $pdo->prepare("
                SELECT p.*, c.name as category_name 
                FROM recommendation_products rp
                JOIN products p ON rp.product_id = p.id
                JOIN categories c ON p.category_id = c.id
                WHERE rp.rule_id = ? AND p.status = 1
                ORDER BY p.created_at DESC
            ");
            $stmt->execute([$rule['id']]);
            $recommendations = $stmt->fetchAll();
        }
        
        // If no products found for this specific rule, show general products for skin type
        if (empty($recommendations)) {
            $stmt = $pdo->prepare("
                SELECT p.*, c.name as category_name 
                FROM products p 
                JOIN categories c ON p.category_id = c.id 
                WHERE p.status = 1 AND p.skin_type = ?
                ORDER BY p.created_at DESC 
                LIMIT 8
            ");
            $stmt->execute([$selected_skin]);
            $recommendations = $stmt->fetchAll();
        }
        
        // If still no products, show all products
        if (empty($recommendations)) {
            $stmt = $pdo->query("
                SELECT p.*, c.name as category_name 
                FROM products p 
                JOIN categories c ON p.category_id = c.id 
                WHERE p.status = 1 
                ORDER BY p.created_at DESC 
                LIMIT 8
            ");
            $recommendations = $stmt->fetchAll();
        }
        
    } catch(PDOException $e) {
        $recommendations = [];
    }
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <div class="row">
        <!-- Sidebar - Selection -->
        <div class="col-lg-3 mb-4">
            <div class="card border-0 shadow-sm sticky-top" style="top: 80px;">
                <div class="card-body p-3">
                    <h6 class="fw-bold mb-3"><i class="bi bi-magic me-2"></i>Find Your Match</h6>
                    
                    <form method="GET" action="">
                        <!-- Skin Type -->
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Skin Type</label>
                            <select class="form-select form-select-sm" name="skin_type" onchange="this.form.submit()">
                                <option value="">Select Skin Type</option>
                                <?php foreach ($skin_labels as $key => $label): ?>
                                    <option value="<?php echo $key; ?>" 
                                        <?php echo $selected_skin === $key ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Skin Concern -->
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Skin Concern</label>
                            <select class="form-select form-select-sm" name="concern" onchange="this.form.submit()">
                                <option value="">Select Concern</option>
                                <?php foreach ($concern_labels as $key => $label): ?>
                                    <option value="<?php echo $key; ?>" 
                                        <?php echo $selected_concern === $key ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary-custom w-100">
                            <i class="bi bi-search me-2"></i>Get Recommendations
                        </button>
                        
                        <?php if ($selected_skin || $selected_concern): ?>
                            <a href="<?php echo BASE_URL; ?>/recommendations.php" class="btn btn-outline-custom w-100 mt-2">
                                <i class="bi bi-arrow-left me-2"></i>Clear All
                            </a>
                        <?php endif; ?>
                    </form>
                    
                    <?php if ($selected_skin && $selected_concern && $recommendation_reason): ?>
                        <hr>
                        <div class="mt-2">
                            <small class="text-muted d-block fw-bold">Why these products?</small>
                            <small class="text-muted"><?php echo e($recommendation_reason); ?></small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Results -->
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h2 class="section-title mb-0">Product Recommendations</h2>
                    <p class="text-muted">
                        <?php if ($selected_skin && $selected_concern): ?>
                            For <strong><?php echo $skin_labels[$selected_skin]; ?></strong> with 
                            <strong><?php echo $concern_labels[$selected_concern]; ?></strong>
                            <span class="badge bg-success ms-2"><?php echo count($recommendations); ?> products</span>
                        <?php else: ?>
                            Select your skin type and concern to get personalized recommendations
                        <?php endif; ?>
                    </p>
                </div>
            </div>
            
            <?php if (empty($selected_skin) || empty($selected_concern)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-hand-index-thumb fs-1 text-muted"></i>
                    <h5 class="mt-3">Select Your Skin Profile</h5>
                    <p class="text-muted">Choose your skin type and concern from the left to see recommended products.</p>
                </div>
                
            <?php elseif (empty($recommendations)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-box-seam fs-1 text-muted"></i>
                    <h5 class="mt-3">No Products Found</h5>
                    <p class="text-muted">
                        No products available for <?php echo $skin_labels[$selected_skin]; ?> with 
                        <?php echo $concern_labels[$selected_concern]; ?> yet.
                    </p>
                    <p class="text-muted">Check back soon or try a different combination!</p>
                    <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-primary-custom">
                        <i class="bi bi-shop me-2"></i>Browse All Products
                    </a>
                </div>
                
            <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($recommendations as $product): ?>
                        <div class="col-6 col-md-4">
                            <div class="product-card">
                                <div class="position-relative">
                                    <?php if ($product['discount_price']): ?>
                                        <span class="badge bg-danger position-absolute top-0 end-0 m-2">
                                            -<?php echo round(($product['price'] - $product['discount_price']) / $product['price'] * 100); ?>%
                                        </span>
                                    <?php endif; ?>
                                    <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>">
                                        <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $product['image'] ?? 'placeholder.jpg'; ?>" 
                                             class="card-img-top" alt="<?php echo e($product['name']); ?>">
                                    </a>
                                </div>
                                <div class="card-body">
                                    <small class="text-muted"><?php echo e($product['category_name']); ?></small>
                                    <h6 class="card-title"><?php echo e($product['name']); ?></h6>
                                    <div class="product-price">
                                        <?php if ($product['discount_price']): ?>
                                            <span class="text-danger"><?php echo formatPrice($product['discount_price']); ?></span>
                                            <span class="original"><?php echo formatPrice($product['price']); ?></span>
                                        <?php else: ?>
                                            <span><?php echo formatPrice($product['price']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Show skin type badge -->
                                    <?php if ($product['skin_type']): ?>
                                        <small class="text-muted d-block mt-1" style="font-size: 0.7rem;">
                                            <i class="bi bi-droplet me-1"></i>For <?php echo ucfirst($product['skin_type']); ?> skin
                                        </small>
                                    <?php endif; ?>
                                    
                                    <div class="d-grid gap-2 mt-2">
                                        <button class="btn btn-sm btn-primary-custom add-to-cart-btn" 
                                                data-product-id="<?php echo $product['id']; ?>">
                                            <i class="bi bi-bag me-1"></i>Add to Cart
                                        </button>
                                        <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>" 
                                           class="btn btn-sm btn-outline-custom">View Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>