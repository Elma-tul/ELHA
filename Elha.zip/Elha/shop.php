<?php
// =====================================================
// SHOP - PRODUCT LISTING WITH FILTERS
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Make sure $pdo is available
global $pdo;

// Get filter parameters
$category = $_GET['category'] ?? '';
$search = $_GET['search'] ?? '';
$min_price = $_GET['min_price'] ?? '';
$max_price = $_GET['max_price'] ?? '';
$sort = $_GET['sort'] ?? 'newest';
$page = (int)($_GET['page'] ?? 1);
$per_page = 12;
$offset = ($page - 1) * $per_page;

// Build query
$where_conditions = ["p.status = 1"];
$params = [];

if (!empty($category)) {
    $where_conditions[] = "c.slug = ?";
    $params[] = $category;
}

if (!empty($search)) {
    $where_conditions[] = "(p.name LIKE ? OR p.description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($min_price)) {
    $where_conditions[] = "COALESCE(p.discount_price, p.price) >= ?";
    $params[] = (float)$min_price;
}

if (!empty($max_price)) {
    $where_conditions[] = "COALESCE(p.discount_price, p.price) <= ?";
    $params[] = (float)$max_price;
}

$where_clause = implode(" AND ", $where_conditions);

// Sorting
$sort_options = [
    'newest' => 'p.created_at DESC',
    'price_low' => 'COALESCE(p.discount_price, p.price) ASC',
    'price_high' => 'COALESCE(p.discount_price, p.price) DESC'
];
$order_by = $sort_options[$sort] ?? $sort_options['newest'];

// Get total count
try {
    $count_sql = "SELECT COUNT(*) FROM products p JOIN categories c ON p.category_id = c.id WHERE $where_clause";
    $stmt = $pdo->prepare($count_sql);
    $stmt->execute($params);
    $total_products = $stmt->fetchColumn();
    $total_pages = ceil($total_products / $per_page);
} catch(PDOException $e) {
    $total_products = 0;
    $total_pages = 0;
}

// Get products
try {
    $sql = "
        SELECT p.*, c.name as category_name, c.slug as category_slug 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE $where_clause 
        ORDER BY $order_by 
        LIMIT $per_page OFFSET $offset
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
} catch(PDOException $e) {
    $products = [];
}

// Get categories for filter
try {
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
    $categories = $stmt->fetchAll();
} catch(PDOException $e) {
    $categories = [];
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <div class="row">
        <!-- Sidebar Filters -->
        <div class="col-lg-3 mb-4">
            <div class="card border-0 shadow-sm sticky-top" style="top: 80px;">
                <div class="card-body p-3">
                    <h6 class="fw-bold mb-3">Filters</h6>
                    
                    <!-- Search -->
                    <form method="GET" action="">
                        <div class="mb-3">
                            <label class="form-label small">Search</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="search" 
                                       placeholder="Search products..." 
                                       value="<?php echo e($_GET['search'] ?? ''); ?>">
                                <button class="btn btn-primary-custom" type="submit">
                                    <i class="bi bi-search"></i>
                                </button>
                            </div>
                        </div>
                        
                        <!-- Category Filter -->
                        <div class="mb-3">
                            <label class="form-label small">Category</label>
                            <select class="form-select" name="category" onchange="this.form.submit()">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo $cat['slug']; ?>" 
                                        <?php echo ($_GET['category'] ?? '') === $cat['slug'] ? 'selected' : ''; ?>>
                                        <?php echo e($cat['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <!-- Price Range -->
                        <div class="mb-3">
                            <label class="form-label small">Price Range</label>
                            <div class="row g-2">
                                <div class="col-6">
                                    <input type="number" class="form-control form-control-sm" name="min_price" 
                                           placeholder="Min" value="<?php echo e($_GET['min_price'] ?? ''); ?>">
                                </div>
                                <div class="col-6">
                                    <input type="number" class="form-control form-control-sm" name="max_price" 
                                           placeholder="Max" value="<?php echo e($_GET['max_price'] ?? ''); ?>">
                                </div>
                            </div>
                        </div>
                        
                        <!-- Sort -->
                        <div class="mb-3">
                            <label class="form-label small">Sort By</label>
                            <select class="form-select" name="sort" onchange="this.form.submit()">
                                <option value="newest" <?php echo ($_GET['sort'] ?? '') === 'newest' ? 'selected' : ''; ?>>Newest</option>
                                <option value="price_low" <?php echo ($_GET['sort'] ?? '') === 'price_low' ? 'selected' : ''; ?>>Price: Low to High</option>
                                <option value="price_high" <?php echo ($_GET['sort'] ?? '') === 'price_high' ? 'selected' : ''; ?>>Price: High to Low</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary-custom w-100">Apply Filters</button>
                        <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-outline-custom w-100 mt-2">Clear All</a>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Product Grid -->
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h4 class="mb-0">Products</h4>
                    <small class="text-muted"><?php echo $total_products; ?> products found</small>
                </div>
            </div>
            
            <?php if (empty($products)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-box-seam fs-1 text-muted"></i>
                    <h5 class="mt-3">No products found</h5>
                    <p class="text-muted">Try adjusting your filters or search terms.</p>
                    <a href="<?php echo BASE_URL; ?>/shop.php" class="btn btn-primary-custom">View All Products</a>
                </div>
            <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($products as $product): ?>
                        <div class="col-6 col-md-4 col-lg-3">
                            <div class="product-card">
                                <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>">
                                    <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $product['image'] ?? 'placeholder.jpg'; ?>" 
                                         class="card-img-top" alt="<?php echo e($product['name']); ?>">
                                </a>
                                <div class="card-body">
                                    <small class="text-muted"><?php echo e($product['category_name']); ?></small>
                                    <h6 class="card-title"><?php echo e($product['name']); ?></h6>
                                    <div class="product-price">
                                        <?php if ($product['discount_price']): ?>
                                            <span class="text-danger"><?php echo formatPrice($product['discount_price']); ?></span>
                                            <span class="original"><?php echo formatPrice($product['price']); ?></span>
                                        <?php else: ?>
                                            <span><?php echo formatPrice($product['price']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $product['id']; ?>" 
                                       class="btn btn-sm btn-primary-custom w-100 mt-2">View Product</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <nav class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>&<?php echo http_build_query(array_filter($_GET, function($k) { return $k !== 'page'; }, ARRAY_FILTER_USE_KEY)); ?>">
                                        Previous
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&<?php echo http_build_query(array_filter($_GET, function($k) { return $k !== 'page'; }, ARRAY_FILTER_USE_KEY)); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>&<?php echo http_build_query(array_filter($_GET, function($k) { return $k !== 'page'; }, ARRAY_FILTER_USE_KEY)); ?>">
                                        Next
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>