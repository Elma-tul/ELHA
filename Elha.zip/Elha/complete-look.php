<?php
// =====================================================
// COMPLETE THE LOOK
// =====================================================

require_once 'config/config.php';
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Get product ID if viewing specific product matches
$product_id = (int)($_GET['product_id'] ?? 0);

// Get all products with matches
try {
    if ($product_id > 0) {
        // Get matches for specific product
        $stmt = $pdo->prepare("
            SELECT 
                p.id as main_product_id,
                p.name as main_product_name,
                p.image as main_product_image,
                p.price as main_product_price,
                p.discount_price as main_product_discount,
                c.name as main_category,
                mp.id as matched_id,
                mp.name as matched_name,
                mp.image as matched_image,
                mp.price as matched_price,
                mp.discount_price as matched_discount,
                mc.name as matched_category
            FROM products p
            JOIN categories c ON p.category_id = c.id
            JOIN product_matches pm ON p.id = pm.product_id
            JOIN products mp ON pm.matched_product_id = mp.id
            JOIN categories mc ON mp.category_id = mc.id
            WHERE p.id = ? AND p.status = 1 AND mp.status = 1
        ");
        $stmt->execute([$product_id]);
        $matches = $stmt->fetchAll();
    } else {
        // Get all products that have matches
        $stmt = $pdo->prepare("
            SELECT DISTINCT 
                p.id,
                p.name,
                p.image,
                p.price,
                p.discount_price,
                c.name as category_name,
                (SELECT COUNT(*) FROM product_matches WHERE product_id = p.id) as match_count
            FROM products p
            JOIN categories c ON p.category_id = c.id
            JOIN product_matches pm ON p.id = pm.product_id
            WHERE p.status = 1
            ORDER BY p.name
        ");
        $stmt->execute();
        $products_with_matches = $stmt->fetchAll();
    }
} catch(PDOException $e) {
    $matches = [];
    $products_with_matches = [];
}

// Get product details if viewing specific product
$main_product = null;
if ($product_id > 0) {
    try {
        $stmt = $pdo->prepare("
            SELECT p.*, c.name as category_name 
            FROM products p 
            JOIN categories c ON p.category_id = c.id 
            WHERE p.id = ? AND p.status = 1
        ");
        $stmt->execute([$product_id]);
        $main_product = $stmt->fetch();
    } catch(PDOException $e) {}
}

include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-4">
    <?php if ($product_id > 0 && $main_product): ?>
        <!-- Viewing matches for specific product -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="section-title mb-0">Complete the Look</h2>
                <p class="text-muted">Products that go with <?php echo e($main_product['name']); ?></p>
            </div>
            <a href="<?php echo BASE_URL; ?>/complete-look.php" class="btn btn-outline-custom">
                <i class="bi bi-arrow-left me-2"></i>View All Looks
            </a>
        </div>
        
        <!-- Main Product -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <div class="row align-items-center">
                    <div class="col-md-3 text-center">
                        <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $main_product['image'] ?? 'placeholder.jpg'; ?>" 
                             alt="<?php echo e($main_product['name']); ?>" 
                             class="img-fluid" style="max-height: 150px; object-fit: contain;">
                    </div>
                    <div class="col-md-6">
                        <h5><?php echo e($main_product['name']); ?></h5>
                        <small class="text-muted"><?php echo e($main_product['category_name']); ?></small>
                        <div class="product-price mt-1">
                            <?php if ($main_product['discount_price']): ?>
                                <span class="text-danger"><?php echo formatPrice($main_product['discount_price']); ?></span>
                                <span class="original"><?php echo formatPrice($main_product['price']); ?></span>
                            <?php else: ?>
                                <span><?php echo formatPrice($main_product['price']); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-3 text-md-end">
                        <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $main_product['id']; ?>" 
                           class="btn btn-primary-custom">
                            View Product
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Matching Products -->
        <?php if (empty($matches)): ?>
            <div class="text-center py-5">
                <i class="bi bi-grid-3x3-gap fs-1 text-muted"></i>
                <h5 class="mt-3">No matching products found</h5>
                <p class="text-muted">This product doesn't have any matching items yet.</p>
            </div>
        <?php else: ?>
            <h5 class="mb-3">Matching Items</h5>
            <div class="row g-4">
                <?php foreach ($matches as $match): ?>
                    <div class="col-6 col-md-3">
                        <div class="product-card">
                            <div class="position-relative">
                                <span class="badge bg-primary position-absolute top-0 start-0 m-2">
                                    <i class="bi bi-check-circle me-1"></i>Matches
                                </span>
                                <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $match['matched_id']; ?>">
                                    <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $match['matched_image'] ?? 'placeholder.jpg'; ?>" 
                                         class="card-img-top" alt="<?php echo e($match['matched_name']); ?>">
                                </a>
                            </div>
                            <div class="card-body">
                                <small class="text-muted"><?php echo e($match['matched_category']); ?></small>
                                <h6 class="card-title"><?php echo e($match['matched_name']); ?></h6>
                                <div class="product-price">
                                    <?php if ($match['matched_discount']): ?>
                                        <span class="text-danger"><?php echo formatPrice($match['matched_discount']); ?></span>
                                        <span class="original"><?php echo formatPrice($match['matched_price']); ?></span>
                                    <?php else: ?>
                                        <span><?php echo formatPrice($match['matched_price']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-sm btn-primary-custom add-to-cart-btn" 
                                            data-product-id="<?php echo $match['matched_id']; ?>">
                                        <i class="bi bi-bag me-1"></i>Add to Cart
                                    </button>
                                    <a href="<?php echo BASE_URL; ?>/product.php?id=<?php echo $match['matched_id']; ?>" 
                                       class="btn btn-sm btn-outline-custom">View</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Add All to Cart -->
            <div class="text-center mt-4">
                <button class="btn btn-primary-custom btn-lg" id="addAllToCart">
                    <i class="bi bi-bag-plus me-2"></i>Add All Items to Cart
                </button>
            </div>
        <?php endif; ?>
        
    <?php else: ?>
        <!-- View all products with matches -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="section-title mb-0">Complete the Look</h2>
                <p class="text-muted">Browse complete looks with matching products</p>
            </div>
        </div>
        
        <?php if (empty($products_with_matches)): ?>
            <div class="text-center py-5">
                <i class="bi bi-grid-3x3-gap fs-1 text-muted"></i>
                <h5 class="mt-3">No looks available yet</h5>
                <p class="text-muted">Check back soon for complete looks!</p>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($products_with_matches as $product): ?>
                    <div class="col-6 col-md-3">
                        <div class="product-card">
                            <a href="<?php echo BASE_URL; ?>/complete-look.php?product_id=<?php echo $product['id']; ?>">
                                <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $product['image'] ?? 'placeholder.jpg'; ?>" 
                                     class="card-img-top" alt="<?php echo e($product['name']); ?>">
                            </a>
                            <div class="card-body">
                                <small class="text-muted"><?php echo e($product['category_name']); ?></small>
                                <h6 class="card-title"><?php echo e($product['name']); ?></h6>
                                <div class="product-price">
                                    <?php if ($product['discount_price']): ?>
                                        <span class="text-danger"><?php echo formatPrice($product['discount_price']); ?></span>
                                        <span class="original"><?php echo formatPrice($product['price']); ?></span>
                                    <?php else: ?>
                                        <span><?php echo formatPrice($product['price']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="mt-2">
                                    <span class="badge bg-info">
                                        <i class="bi bi-shuffle me-1"></i><?php echo $product['match_count']; ?> matches
                                    </span>
                                </div>
                                <a href="<?php echo BASE_URL; ?>/complete-look.php?product_id=<?php echo $product['id']; ?>" 
                                   class="btn btn-sm btn-primary-custom w-100 mt-2">
                                    <i class="bi bi-grid-3x3-gap me-1"></i>Complete the Look
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>