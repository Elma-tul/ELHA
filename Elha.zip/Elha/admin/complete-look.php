<?php
// =====================================================
// ADMIN - COMPLETE THE LOOK MANAGEMENT
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';


// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = '';

// Get all products for dropdowns
try {
    $stmt = $pdo->query("
        SELECT p.*, c.name as category_name 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE p.status = 1 
        ORDER BY c.name, p.name
    ");
    $all_products = $stmt->fetchAll();
} catch(PDOException $e) {
    $all_products = [];
}

// Handle Add Match
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_match'])) {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $matched_product_id = (int)($_POST['matched_product_id'] ?? 0);
    
    if ($product_id <= 0 || $matched_product_id <= 0) {
        $error = 'Please select both products.';
    } elseif ($product_id == $matched_product_id) {
        $error = 'Cannot match a product with itself.';
    } else {
        try {
            // Check if match already exists
            $stmt = $pdo->prepare("
                SELECT id FROM product_matches 
                WHERE product_id = ? AND matched_product_id = ?
            ");
            $stmt->execute([$product_id, $matched_product_id]);
            
            if ($stmt->fetch()) {
                $error = 'This match already exists.';
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO product_matches (product_id, matched_product_id) 
                    VALUES (?, ?)
                ");
                $stmt->execute([$product_id, $matched_product_id]);
                $success = 'Match added successfully!';
            }
        } catch(PDOException $e) {
            $error = 'Failed to add match: ' . $e->getMessage();
        }
    }
}

// Handle Delete Match
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM product_matches WHERE id = ?");
        $stmt->execute([$id]);
        $success = 'Match deleted successfully!';
    } catch(PDOException $e) {
        $error = 'Failed to delete match.';
    }
}

// Get all matches with product details
try {
    $stmt = $pdo->query("
        SELECT 
            pm.id,
            pm.product_id,
            pm.matched_product_id,
            p1.name as product_name,
            p1.image as product_image,
            c1.name as product_category,
            p2.name as matched_name,
            p2.image as matched_image,
            c2.name as matched_category
        FROM product_matches pm
        JOIN products p1 ON pm.product_id = p1.id
        JOIN categories c1 ON p1.category_id = c1.id
        JOIN products p2 ON pm.matched_product_id = p2.id
        JOIN categories c2 ON p2.category_id = c2.id
        ORDER BY p1.name, p2.name
    ");
    $matches = $stmt->fetchAll();
} catch(PDOException $e) {
    $matches = [];
}

include 'includes/admin-header.php';
include 'includes/admin-sidebar.php';
?>

<div class="admin-content">
    <div class="admin-topbar">
        <h5>Complete the Look Management</h5>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?php echo $error; ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <div class="row g-4">
        <!-- Add Match Form -->
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="bi bi-plus-circle me-2"></i>Add New Match</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="product_id" class="form-label">Main Product</label>
                            <select class="form-select" id="product_id" name="product_id" required>
                                <option value="">Select Product</option>
                                <?php foreach ($all_products as $product): ?>
                                    <option value="<?php echo $product['id']; ?>">
                                        <?php echo htmlspecialchars($product['name']); ?> 
                                        (<?php echo htmlspecialchars($product['category_name']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="matched_product_id" class="form-label">Matching Product</label>
                            <select class="form-select" id="matched_product_id" name="matched_product_id" required>
                                <option value="">Select Product</option>
                                <?php foreach ($all_products as $product): ?>
                                    <option value="<?php echo $product['id']; ?>">
                                        <?php echo htmlspecialchars($product['name']); ?> 
                                        (<?php echo htmlspecialchars($product['category_name']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <button type="submit" name="add_match" class="btn btn-primary-custom w-100">
                            <i class="bi bi-link me-2"></i>Add Match
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="card border-0 shadow-sm mt-3">
                <div class="card-body">
                    <h6 class="fw-bold mb-2">How it works:</h6>
                    <ul class="text-muted small">
                        <li>Select a <strong>Main Product</strong></li>
                        <li>Select a <strong>Matching Product</strong></li>
                        <li>When customers view the main product, they'll see matching items</li>
                        <li>Matches work both ways</li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Matches List -->
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0">Current Matches (<?php echo count($matches); ?>)</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Main Product</th>
                                    <th>→</th>
                                    <th>Matching Product</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($matches)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-4 text-muted">No matches found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($matches as $match): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center gap-2">
                                                    <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $match['product_image'] ?? 'placeholder.jpg'; ?>" 
                                                         alt="<?php echo htmlspecialchars($match['product_name']); ?>" 
                                                         style="width: 40px; height: 40px; object-fit: cover; border-radius: 8px;">
                                                    <div>
                                                        <div><?php echo htmlspecialchars($match['product_name']); ?></div>
                                                        <small class="text-muted"><?php echo htmlspecialchars($match['product_category']); ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="text-center"><i class="bi bi-arrow-right fs-5 text-primary"></i></td>
                                            <td>
                                                <div class="d-flex align-items-center gap-2">
                                                    <img src="<?php echo BASE_URL; ?>/assets/images/products/<?php echo $match['matched_image'] ?? 'placeholder.jpg'; ?>" 
                                                         alt="<?php echo htmlspecialchars($match['matched_name']); ?>" 
                                                         style="width: 40px; height: 40px; object-fit: cover; border-radius: 8px;">
                                                    <div>
                                                        <div><?php echo htmlspecialchars($match['matched_name']); ?></div>
                                                        <small class="text-muted"><?php echo htmlspecialchars($match['matched_category']); ?></small>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <a href="?delete=<?php echo $match['id']; ?>" 
                                                   class="btn btn-sm btn-danger" 
                                                   onclick="return confirm('Are you sure you want to remove this match?')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/admin-footer.php'; ?>