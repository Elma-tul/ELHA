<?php
// =====================================================
// FINAL TEST - Shows everything
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';

echo "<h2>Final Admin Test</h2>";

// 1. Check database connection
try {
    $stmt = $pdo->query("SELECT 1");
    echo "✅ Database connected<br>";
} catch(PDOException $e) {
    echo "❌ Database connection failed: " . $e->getMessage() . "<br>";
}

// 2. Check admins table
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'admins'");
    if ($stmt->rowCount() > 0) {
        echo "✅ admins table exists<br>";
    } else {
        echo "❌ admins table does NOT exist!<br>";
    }
} catch(PDOException $e) {
    echo "❌ Error checking table: " . $e->getMessage() . "<br>";
}

// 3. Check admin record
try {
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->execute(['elha@gmail.com']);
    $admin = $stmt->fetch();
    
    if ($admin) {
        echo "<h3>✅ Admin Record Found:</h3>";
        echo "<pre>";
        print_r($admin);
        echo "</pre>";
        
        // Check password
        $test_password = 'elha123';
        if ($test_password === $admin['password']) {
            echo "<span style='color: green; font-size: 24px;'>✅✅✅ PASSWORD MATCHES! Login will work!</span><br>";
            echo "Email: elha@gmail.com<br>";
            echo "Password: elha123";
        } else {
            echo "<span style='color: red; font-size: 24px;'>❌ PASSWORD DOES NOT MATCH!</span><br>";
            echo "Stored: '" . $admin['password'] . "'<br>";
            echo "Expected: 'elha123'<br>";
            echo "<br><strong>Run this SQL to fix:</strong><br>";
            echo "UPDATE admins SET password = 'elha123' WHERE email = 'elha@gmail.com';";
        }
    } else {
        echo "❌ No admin found with email: elha@gmail.com<br>";
        echo "<br><strong>Run this SQL to fix:</strong><br>";
        echo "INSERT INTO admins (name, email, password) VALUES ('ELHA', 'elha@gmail.com', 'elha123');";
    }
} catch(PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
}

// 4. Show all admins
try {
    $stmt = $pdo->query("SELECT * FROM admins");
    echo "<h3>All Admins in Database:</h3>";
    while ($row = $stmt->fetch()) {
        echo "ID: " . $row['id'] . " | Email: " . $row['email'] . " | Password: " . $row['password'] . "<br>";
    }
} catch(PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>