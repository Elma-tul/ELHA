<?php
// =====================================================
// ADMIN - CUSTOMERS MANAGEMENT
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';


// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Get search term
$search = $_GET['search'] ?? '';

// Build query
$where = '';
$params = [];
if (!empty($search)) {
    $where = "WHERE name LIKE ? OR email LIKE ? OR phone LIKE ?";
    $search_term = "%$search%";
    $params = [$search_term, $search_term, $search_term];
}

// Get all customers
try {
    $sql = "SELECT * FROM users $where ORDER BY created_at DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $customers = $stmt->fetchAll();
} catch(PDOException $e) {
    $customers = [];
}

// Toggle customer status
if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    try {
        $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $current = $stmt->fetchColumn();
        $new_status = $current ? 0 : 1;
        
        $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
        $stmt->execute([$new_status, $id]);
        $success = 'Customer status updated successfully!';
        
        // Refresh customers
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $customers = $stmt->fetchAll();
    } catch(PDOException $e) {
        $error = 'Failed to update customer status.';
    }
}

include 'includes/admin-header.php';
include 'includes/admin-sidebar.php';
?>

<div class="admin-content">
    <div class="admin-topbar">
        <h5>Customers Management</h5>
    </div>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success alert-dismissible fade show"><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?php echo $error; ?></div>
    <?php endif; ?>
    
    <!-- Search -->
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="">
                <div class="input-group">
                    <input type="text" class="form-control" name="search" 
                           placeholder="Search by name, email or phone..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search me-2"></i>Search
                    </button>
                    <?php if (!empty($search)): ?>
                        <a href="<?php echo BASE_URL; ?>/admin/customers.php" class="btn btn-outline-secondary">
                            Clear
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Customers List -->
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Orders</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($customers)): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">No customers found</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($customers as $customer): ?>
                                <?php 
                                    // Get order count
                                    try {
                                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?");
                                        $stmt->execute([$customer['id']]);
                                        $order_count = $stmt->fetchColumn();
                                    } catch(PDOException $e) {
                                        $order_count = 0;
                                    }
                                ?>
                                <tr>
                                    <td><?php echo $customer['id']; ?></td>
                                    <td><?php echo htmlspecialchars($customer['name']); ?></td>
                                    <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                    <td><?php echo htmlspecialchars($customer['phone'] ?? '-'); ?></td>
                                    <td>
                                        <span class="badge bg-info"><?php echo $order_count; ?></span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $customer['is_active'] ? 'bg-success' : 'bg-danger'; ?>">
                                            <?php echo $customer['is_active'] ? 'Active' : 'Inactive'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d M Y', strtotime($customer['created_at'])); ?></td>
                                    <td>
                                        <a href="?toggle=<?php echo $customer['id']; ?>" 
                                           class="btn btn-sm <?php echo $customer['is_active'] ? 'btn-warning' : 'btn-success'; ?>"
                                           onclick="return confirm('Toggle customer status?')">
                                            <i class="bi <?php echo $customer['is_active'] ? 'bi-pause' : 'bi-play'; ?>"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/admin-footer.php'; ?>