<?php
// =====================================================
// ADMIN - ADD PRODUCT
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';


// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Get categories for dropdown
try {
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
    $categories = $stmt->fetchAll();
} catch(PDOException $e) {
    $categories = [];
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $discount_price = !empty($_POST['discount_price']) ? (float)$_POST['discount_price'] : null;
    $stock = (int)($_POST['stock'] ?? 0);
    $status = isset($_POST['status']) ? 1 : 0;
    $skin_type = $_POST['skin_type'] ?? null;
    $skin_concern = $_POST['skin_concern'] ?? null;
    $gift_suitable = isset($_POST['gift_suitable']) ? 1 : 0;
    $occasion = $_POST['occasion'] ?? null;
    $recipient = $_POST['recipient'] ?? null;
    
    // Validate
    if (empty($name) || $category_id <= 0 || $price <= 0) {
        $error = 'Please fill all required fields.';
    } else {
        try {
            // Handle image upload
            $image_path = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = '../assets/images/products/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                $file_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                $allowed_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                
                if (in_array($file_ext, $allowed_exts)) {
                    $file_name = 'product_' . time() . '.' . $file_ext;
                    $file_path = $upload_dir . $file_name;
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $file_path)) {
                        $image_path = $file_name;
                    }
                }
            }
            
            // Generate slug
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
            
            // Insert product
            $stmt = $pdo->prepare("
                INSERT INTO products (
                    name, slug, category_id, description, price, discount_price, 
                    stock, image, skin_type, skin_concern, gift_suitable, 
                    occasion, recipient, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $name, $slug, $category_id, $description, $price, $discount_price,
                $stock, $image_path, $skin_type, $skin_concern, $gift_suitable,
                $occasion, $recipient, $status
            ]);
            
            $success = 'Product added successfully!';
            
            // Clear form
            $_POST = [];
            
        } catch(PDOException $e) {
            $error = 'Failed to add product: ' . $e->getMessage();
        }
    }
}

include 'includes/admin-header.php';
include 'includes/admin-sidebar.php';
?>

<div class="admin-content">
    <div class="admin-topbar">
        <h5>Add New Product</h5>
        <a href="<?php echo BASE_URL; ?>/admin/products.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-2"></i>Back to Products
        </a>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="row g-3">
                    <!-- Product Name -->
                    <div class="col-md-6">
                        <label for="name" class="form-label">Product Name *</label>
                        <input type="text" class="form-control" id="name" name="name" 
                               value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                    </div>
                    
                    <!-- Category -->
                    <div class="col-md-6">
                        <label for="category_id" class="form-label">Category *</label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                    <?php echo (($_POST['category_id'] ?? 0) == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Description -->
                    <div class="col-12">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                    </div>
                    
                    <!-- Price -->
                    <div class="col-md-4">
                        <label for="price" class="form-label">Price *</label>
                        <input type="number" step="0.01" class="form-control" id="price" name="price" 
                               value="<?php echo $_POST['price'] ?? ''; ?>" required>
                    </div>
                    
                    <!-- Discount Price -->
                    <div class="col-md-4">
                        <label for="discount_price" class="form-label">Discount Price</label>
                        <input type="number" step="0.01" class="form-control" id="discount_price" name="discount_price" 
                               value="<?php echo $_POST['discount_price'] ?? ''; ?>">
                    </div>
                    
                    <!-- Stock -->
                    <div class="col-md-4">
                        <label for="stock" class="form-label">Stock *</label>
                        <input type="number" class="form-control" id="stock" name="stock" 
                               value="<?php echo $_POST['stock'] ?? 0; ?>" required>
                    </div>
                    
                    <!-- Image -->
                    <div class="col-12">
                        <label for="image" class="form-label">Product Image</label>
                        <input type="file" class="form-control" id="image" name="image" accept="image/*">
                        <small class="text-muted">Supported formats: JPG, PNG, GIF, WEBP</small>
                    </div>
                    
                    <!-- Skin Type -->
                    <div class="col-md-6">
                        <label for="skin_type" class="form-label">Skin Type</label>
                        <select class="form-select" id="skin_type" name="skin_type">
                            <option value="">None</option>
                            <option value="oily" <?php echo ($_POST['skin_type'] ?? '') == 'oily' ? 'selected' : ''; ?>>Oily</option>
                            <option value="dry" <?php echo ($_POST['skin_type'] ?? '') == 'dry' ? 'selected' : ''; ?>>Dry</option>
                            <option value="combination" <?php echo ($_POST['skin_type'] ?? '') == 'combination' ? 'selected' : ''; ?>>Combination</option>
                            <option value="normal" <?php echo ($_POST['skin_type'] ?? '') == 'normal' ? 'selected' : ''; ?>>Normal</option>
                        </select>
                    </div>
                    
                    <!-- Skin Concern -->
                    <div class="col-md-6">
                        <label for="skin_concern" class="form-label">Skin Concern</label>
                        <select class="form-select" id="skin_concern" name="skin_concern">
                            <option value="">None</option>
                            <option value="acne" <?php echo ($_POST['skin_concern'] ?? '') == 'acne' ? 'selected' : ''; ?>>Acne</option>
                            <option value="dark spots" <?php echo ($_POST['skin_concern'] ?? '') == 'dark spots' ? 'selected' : ''; ?>>Dark Spots</option>
                            <option value="dryness" <?php echo ($_POST['skin_concern'] ?? '') == 'dryness' ? 'selected' : ''; ?>>Dryness</option>
                            <option value="sensitive" <?php echo ($_POST['skin_concern'] ?? '') == 'sensitive' ? 'selected' : ''; ?>>Sensitive</option>
                            <option value="dullness" <?php echo ($_POST['skin_concern'] ?? '') == 'dullness' ? 'selected' : ''; ?>>Dullness</option>
                            <option value="uneven tone" <?php echo ($_POST['skin_concern'] ?? '') == 'uneven tone' ? 'selected' : ''; ?>>Uneven Tone</option>
                        </select>
                    </div>
                    
                    <!-- Gift Options -->
                    <div class="col-md-4">
                        <div class="form-check mt-4">
                            <input class="form-check-input" type="checkbox" id="gift_suitable" name="gift_suitable" 
                                   <?php echo isset($_POST['gift_suitable']) ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="gift_suitable">
                                Suitable as Gift
                            </label>
                        </div>
                    </div>
                    
                    <!-- Occasion -->
                    <div class="col-md-4">
                        <label for="occasion" class="form-label">Occasion</label>
                        <select class="form-select" id="occasion" name="occasion">
                            <option value="">None</option>
                            <option value="Birthday" <?php echo ($_POST['occasion'] ?? '') == 'Birthday' ? 'selected' : ''; ?>>Birthday</option>
                            <option value="Anniversary" <?php echo ($_POST['occasion'] ?? '') == 'Anniversary' ? 'selected' : ''; ?>>Anniversary</option>
                            <option value="Valentine's Day" <?php echo ($_POST['occasion'] ?? '') == "Valentine's Day" ? 'selected' : ''; ?>>Valentine's Day</option>
                            <option value="Wedding" <?php echo ($_POST['occasion'] ?? '') == 'Wedding' ? 'selected' : ''; ?>>Wedding</option>
                            <option value="Eid" <?php echo ($_POST['occasion'] ?? '') == 'Eid' ? 'selected' : ''; ?>>Eid</option>
                            <option value="Christmas" <?php echo ($_POST['occasion'] ?? '') == 'Christmas' ? 'selected' : ''; ?>>Christmas</option>
                            <option value="Graduation" <?php echo ($_POST['occasion'] ?? '') == 'Graduation' ? 'selected' : ''; ?>>Graduation</option>
                            <option value="General" <?php echo ($_POST['occasion'] ?? '') == 'General' ? 'selected' : ''; ?>>General</option>
                        </select>
                    </div>
                    
                    <!-- Recipient -->
                    <div class="col-md-4">
                        <label for="recipient" class="form-label">Recipient</label>
                        <select class="form-select" id="recipient" name="recipient">
                            <option value="">None</option>
                            <option value="Mother" <?php echo ($_POST['recipient'] ?? '') == 'Mother' ? 'selected' : ''; ?>>Mother</option>
                            <option value="Sister" <?php echo ($_POST['recipient'] ?? '') == 'Sister' ? 'selected' : ''; ?>>Sister</option>
                            <option value="Friend" <?php echo ($_POST['recipient'] ?? '') == 'Friend' ? 'selected' : ''; ?>>Friend</option>
                            <option value="Wife" <?php echo ($_POST['recipient'] ?? '') == 'Wife' ? 'selected' : ''; ?>>Wife</option>
                            <option value="Girlfriend" <?php echo ($_POST['recipient'] ?? '') == 'Girlfriend' ? 'selected' : ''; ?>>Girlfriend</option>
                            <option value="Husband" <?php echo ($_POST['recipient'] ?? '') == 'Husband' ? 'selected' : ''; ?>>Husband</option>
                            <option value="Boyfriend" <?php echo ($_POST['recipient'] ?? '') == 'Boyfriend' ? 'selected' : ''; ?>>Boyfriend</option>
                        </select>
                    </div>
                    
                    <!-- Status -->
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="status" name="status" 
                                   <?php echo !isset($_POST['status']) || $_POST['status'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="status">
                                Active (Visible on website)
                            </label>
                        </div>
                    </div>
                    
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary-custom">Add Product</button>
                        <a href="<?php echo BASE_URL; ?>/admin/products.php" class="btn btn-outline-secondary ms-2">Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/admin-footer.php'; ?>