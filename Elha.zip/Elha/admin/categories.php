<?php
// =====================================================
// ADMIN - CATEGORIES MANAGEMENT
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';


// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = '';

// Handle Add/Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $icon = trim($_POST['icon'] ?? 'bi-tag');
    
    if (empty($name)) {
        $error = 'Category name is required.';
    } else {
        try {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
            
            if ($id > 0) {
                // Update
                $stmt = $pdo->prepare("UPDATE categories SET name = ?, slug = ?, description = ?, icon = ? WHERE id = ?");
                $stmt->execute([$name, $slug, $description, $icon, $id]);
                $success = 'Category updated successfully!';
            } else {
                // Insert
                $stmt = $pdo->prepare("INSERT INTO categories (name, slug, description, icon) VALUES (?, ?, ?, ?)");
                $stmt->execute([$name, $slug, $description, $icon]);
                $success = 'Category added successfully!';
            }
        } catch(PDOException $e) {
            $error = 'Failed to save category: ' . $e->getMessage();
        }
    }
}

// Handle Delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $success = 'Category deleted successfully!';
    } catch(PDOException $e) {
        $error = 'Failed to delete category. Make sure no products are using this category.';
    }
}

// Get all categories
try {
    $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
    $categories = $stmt->fetchAll();
} catch(PDOException $e) {
    $categories = [];
}

// Get category for edit
$edit_category = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $edit_category = $stmt->fetch();
    } catch(PDOException $e) {}
}

include 'includes/admin-header.php';
include 'includes/admin-sidebar.php';
?>

<div class="admin-content">
    <div class="admin-topbar">
        <h5>Categories Management</h5>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?php echo $error; ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <div class="row g-4">
        <!-- Add/Edit Form -->
        <div class="col-lg-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><?php echo $edit_category ? 'Edit Category' : 'Add New Category'; ?></h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <?php if ($edit_category): ?>
                            <input type="hidden" name="id" value="<?php echo $edit_category['id']; ?>">
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label for="name" class="form-label">Category Name *</label>
                            <input type="text" class="form-control" id="name" name="name" 
                                   value="<?php echo htmlspecialchars($edit_category['name'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="2"><?php echo htmlspecialchars($edit_category['description'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="icon" class="form-label">Icon (Bootstrap Icon Class)</label>
                            <input type="text" class="form-control" id="icon" name="icon" 
                                   value="<?php echo htmlspecialchars($edit_category['icon'] ?? 'bi-tag'); ?>">
                            <small class="text-muted">Example: bi-bag, bi-gem, bi-brush</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary-custom">
                            <?php echo $edit_category ? 'Update Category' : 'Add Category'; ?>
                        </button>
                        <?php if ($edit_category): ?>
                            <a href="<?php echo BASE_URL; ?>/admin/categories.php" class="btn btn-outline-secondary ms-2">Cancel</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Categories List -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0">All Categories</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Slug</th>
                                    <th>Products</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($categories)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-4 text-muted">No categories found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($categories as $cat): ?>
                                        <?php 
                                            // Get product count for this category
                                            try {
                                                $stmt = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = ?");
                                                $stmt->execute([$cat['id']]);
                                                $product_count = $stmt->fetchColumn();
                                            } catch(PDOException $e) {
                                                $product_count = 0;
                                            }
                                        ?>
                                        <tr>
                                            <td><?php echo $cat['id']; ?></td>
                                            <td><?php echo htmlspecialchars($cat['name']); ?></td>
                                            <td><code><?php echo $cat['slug']; ?></code></td>
                                            <td>
                                                <span class="badge bg-info"><?php echo $product_count; ?></span>
                                            </td>
                                            <td>
                                                <a href="?edit=<?php echo $cat['id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="?delete=<?php echo $cat['id']; ?>" 
                                                   class="btn btn-sm btn-danger" 
                                                   onclick="return confirm('Are you sure you want to delete this category?')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/admin-footer.php'; ?>