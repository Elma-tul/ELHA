<?php
// =====================================================
// ADMIN PASSWORD RESET - DELETE AFTER USE
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';

// New password: Admin@123
$email = 'admin@elha.com';
$password = password_hash('Admin@123', PASSWORD_DEFAULT);

try {
    // Check if admin exists
    $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ?");
    $stmt->execute([$email]);
    $exists = $stmt->fetch();
    
    if ($exists) {
        // Update existing
        $stmt = $pdo->prepare("UPDATE admins SET password = ? WHERE email = ?");
        $stmt->execute([$password, $email]);
        echo "✅ Password updated successfully!<br>";
        echo "Email: admin@elha.com<br>";
        echo "Password: Admin@123";
    } else {
        // Insert new
        $stmt = $pdo->prepare("INSERT INTO admins (name, email, password) VALUES (?, ?, ?)");
        $stmt->execute(['Admin ELHA', $email, $password]);
        echo "✅ Admin account created successfully!<br>";
        echo "Email: admin@elha.com<br>";
        echo "Password: Admin@123";
    }
} catch(PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>