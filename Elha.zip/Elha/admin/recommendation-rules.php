<?php
// =====================================================
// ADMIN - RECOMMENDATION RULES MANAGEMENT
// =====================================================

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../includes/functions.php';


// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

$error = '';
$success = '';

// Get all products for dropdowns
try {
    $stmt = $pdo->query("
        SELECT p.*, c.name as category_name 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE p.status = 1 
        ORDER BY c.name, p.name
    ");
    $all_products = $stmt->fetchAll();
} catch(PDOException $e) {
    $all_products = [];
}

// Get all rules
try {
    $stmt = $pdo->query("
        SELECT r.*, 
               GROUP_CONCAT(p.name SEPARATOR ', ') as product_names,
               GROUP_CONCAT(rp.product_id SEPARATOR ',') as product_ids
        FROM recommendation_rules r
        LEFT JOIN recommendation_products rp ON r.id = rp.rule_id
        LEFT JOIN products p ON rp.product_id = p.id
        GROUP BY r.id
        ORDER BY r.skin_type, r.concern
    ");
    $rules = $stmt->fetchAll();
} catch(PDOException $e) {
    $rules = [];
}

// Handle Add/Edit Rule
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $rule_id = (int)($_POST['rule_id'] ?? 0);
    $skin_type = $_POST['skin_type'] ?? '';
    $concern = $_POST['concern'] ?? '';
    $description = trim($_POST['description'] ?? '');
    $product_ids = $_POST['product_ids'] ?? [];
    
    if (empty($skin_type) || empty($concern)) {
        $error = 'Please select skin type and concern.';
    } elseif (empty($product_ids)) {
        $error = 'Please select at least one product.';
    } else {
        try {
            if ($action === 'edit' && $rule_id > 0) {
                // Update rule
                $stmt = $pdo->prepare("
                    UPDATE recommendation_rules 
                    SET skin_type = ?, concern = ?, description = ? 
                    WHERE id = ?
                ");
                $stmt->execute([$skin_type, $concern, $description, $rule_id]);
                
                // Delete old product associations
                $stmt = $pdo->prepare("DELETE FROM recommendation_products WHERE rule_id = ?");
                $stmt->execute([$rule_id]);
                
                // Add new product associations
                foreach ($product_ids as $product_id) {
                    $stmt = $pdo->prepare("
                        INSERT INTO recommendation_products (rule_id, product_id) 
                        VALUES (?, ?)
                    ");
                    $stmt->execute([$rule_id, $product_id]);
                }
                
                $success = 'Rule updated successfully!';
            } else {
                // Insert new rule
                $stmt = $pdo->prepare("
                    INSERT INTO recommendation_rules (skin_type, concern, description) 
                    VALUES (?, ?, ?)
                ");
                $stmt->execute([$skin_type, $concern, $description]);
                $rule_id = $pdo->lastInsertId();
                
                // Add product associations
                foreach ($product_ids as $product_id) {
                    $stmt = $pdo->prepare("
                        INSERT INTO recommendation_products (rule_id, product_id) 
                        VALUES (?, ?)
                    ");
                    $stmt->execute([$rule_id, $product_id]);
                }
                
                $success = 'Rule added successfully!';
            }
            
            // Refresh rules
            $stmt = $pdo->query("
                SELECT r.*, 
                       GROUP_CONCAT(p.name SEPARATOR ', ') as product_names,
                       GROUP_CONCAT(rp.product_id SEPARATOR ',') as product_ids
                FROM recommendation_rules r
                LEFT JOIN recommendation_products rp ON r.id = rp.rule_id
                LEFT JOIN products p ON rp.product_id = p.id
                GROUP BY r.id
                ORDER BY r.skin_type, r.concern
            ");
            $rules = $stmt->fetchAll();
            
        } catch(PDOException $e) {
            $error = 'Failed to save rule: ' . $e->getMessage();
        }
    }
}

// Handle Delete Rule
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        // Delete product associations first
        $stmt = $pdo->prepare("DELETE FROM recommendation_products WHERE rule_id = ?");
        $stmt->execute([$id]);
        
        // Delete rule
        $stmt = $pdo->prepare("DELETE FROM recommendation_rules WHERE id = ?");
        $stmt->execute([$id]);
        
        $success = 'Rule deleted successfully!';
        
        // Refresh rules
        $stmt = $pdo->query("
            SELECT r.*, 
                   GROUP_CONCAT(p.name SEPARATOR ', ') as product_names,
                   GROUP_CONCAT(rp.product_id SEPARATOR ',') as product_ids
            FROM recommendation_rules r
            LEFT JOIN recommendation_products rp ON r.id = rp.rule_id
            LEFT JOIN products p ON rp.product_id = p.id
            GROUP BY r.id
            ORDER BY r.skin_type, r.concern
        ");
        $rules = $stmt->fetchAll();
        
    } catch(PDOException $e) {
        $error = 'Failed to delete rule.';
    }
}

// Get rule for editing
$edit_rule = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("
            SELECT r.*, 
                   GROUP_CONCAT(rp.product_id SEPARATOR ',') as product_ids
            FROM recommendation_rules r
            LEFT JOIN recommendation_products rp ON r.id = rp.rule_id
            WHERE r.id = ?
            GROUP BY r.id
        ");
        $stmt->execute([$id]);
        $edit_rule = $stmt->fetch();
        
        if ($edit_rule) {
            $edit_rule['product_ids'] = explode(',', $edit_rule['product_ids'] ?? '');
        }
    } catch(PDOException $e) {}
}

// Define skin types and concerns
$skin_types = ['oily', 'dry', 'combination', 'normal'];
$concerns = ['acne', 'dark spots', 'dryness', 'sensitive', 'dullness', 'uneven tone'];

include 'includes/admin-header.php';
include 'includes/admin-sidebar.php';
?>

<div class="admin-content">
    <div class="admin-topbar">
        <h5>Recommendation Rules Management</h5>
    </div>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show"><?php echo $error; ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <div class="row g-4">
        <!-- Add/Edit Form -->
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0">
                        <?php echo $edit_rule ? 'Edit Rule' : 'Add New Rule'; ?>
                    </h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="<?php echo $edit_rule ? 'edit' : 'add'; ?>">
                        <?php if ($edit_rule): ?>
                            <input type="hidden" name="rule_id" value="<?php echo $edit_rule['id']; ?>">
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label for="skin_type" class="form-label">Skin Type *</label>
                            <select class="form-select" id="skin_type" name="skin_type" required>
                                <option value="">Select Skin Type</option>
                                <?php foreach ($skin_types as $type): ?>
                                    <option value="<?php echo $type; ?>" 
                                        <?php echo ($edit_rule['skin_type'] ?? '') == $type ? 'selected' : ''; ?>>
                                        <?php echo ucfirst($type); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="concern" class="form-label">Skin Concern *</label>
                            <select class="form-select" id="concern" name="concern" required>
                                <option value="">Select Concern</option>
                                <?php foreach ($concerns as $concern): ?>
                                    <option value="<?php echo $concern; ?>" 
                                        <?php echo ($edit_rule['concern'] ?? '') == $concern ? 'selected' : ''; ?>>
                                        <?php echo ucfirst($concern); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="2"><?php echo htmlspecialchars($edit_rule['description'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Recommended Products *</label>
                            <select class="form-select" name="product_ids[]" multiple size="6" required>
                                <?php foreach ($all_products as $product): ?>
                                    <option value="<?php echo $product['id']; ?>"
                                        <?php 
                                            if ($edit_rule && in_array($product['id'], $edit_rule['product_ids'] ?? [])) {
                                                echo 'selected';
                                            }
                                        ?>>
                                        <?php echo htmlspecialchars($product['name']); ?> 
                                        (<?php echo htmlspecialchars($product['category_name']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="text-muted">Hold Ctrl/Cmd to select multiple products</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary-custom w-100">
                            <?php echo $edit_rule ? 'Update Rule' : 'Add Rule'; ?>
                        </button>
                        <?php if ($edit_rule): ?>
                            <a href="<?php echo BASE_URL; ?>/admin/recommendation-rules.php" class="btn btn-outline-secondary w-100 mt-2">
                                Cancel
                            </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        
        <!-- Rules List -->
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="mb-0">Current Rules (<?php echo count($rules); ?>)</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th>Skin Type</th>
                                    <th>Concern</th>
                                    <th>Products</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($rules)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-4 text-muted">No rules found</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($rules as $rule): ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-primary">
                                                    <?php echo ucfirst($rule['skin_type']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-info">
                                                    <?php echo ucfirst($rule['concern']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php 
                                                    $product_names = explode(', ', $rule['product_names'] ?? '');
                                                    $display_names = array_slice($product_names, 0, 3);
                                                    echo implode(', ', $display_names);
                                                    if (count($product_names) > 3) {
                                                        echo ' +' . (count($product_names) - 3) . ' more';
                                                    }
                                                ?>
                                            </td>
                                            <td>
                                                <a href="?edit=<?php echo $rule['id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="?delete=<?php echo $rule['id']; ?>" 
                                                   class="btn btn-sm btn-danger" 
                                                   onclick="return confirm('Are you sure you want to delete this rule?')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/admin-footer.php'; ?>