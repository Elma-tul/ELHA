<?php
// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: ' . BASE_URL . '/admin/login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - ELHA</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --admin-primary: #2d1b20;
            --admin-secondary: #e8a0b4;
            --admin-light: #fdf8f9;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f5f6fa;
        }
        .admin-sidebar {
            background: var(--admin-primary);
            min-height: 100vh;
            padding: 20px 0;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 250px;
            overflow-y: auto;
            z-index: 1000;
        }
        .admin-sidebar .brand {
            color: white;
            font-size: 1.5rem;
            font-weight: 700;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: block;
            text-decoration: none;
        }
        .admin-sidebar .brand small {
            display: block;
            font-size: 0.7rem;
            font-weight: 300;
            color: rgba(255,255,255,0.5);
            letter-spacing: 2px;
        }
        .admin-sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 20px;
            border-radius: 8px;
            transition: all 0.3s;
            margin: 2px 10px;
        }
        .admin-sidebar .nav-link:hover,
        .admin-sidebar .nav-link.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        .admin-sidebar .nav-link i {
            margin-right: 10px;
            width: 20px;
        }
        .admin-content {
            margin-left: 250px;
            padding: 20px;
        }
        .admin-topbar {
            background: white;
            padding: 15px 30px;
            border-radius: 12px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .admin-topbar h5 {
            margin: 0;
        }
        .admin-topbar .user-info {
            color: #666;
            font-size: 0.9rem;
        }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-3px);
        }
        .stat-card .stat-icon {
            font-size: 2rem;
            color: var(--admin-secondary);
        }
        .stat-card .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
        }
        .stat-card .stat-label {
            color: #8a7a7f;
            font-size: 0.9rem;
        }
        @media (max-width: 768px) {
            .admin-sidebar {
                width: 100%;
                position: relative;
                min-height: auto;
            }
            .admin-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>