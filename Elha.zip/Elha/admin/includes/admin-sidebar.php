<div class="admin-sidebar">
    <a href="<?php echo BASE_URL; ?>/admin/index.php" class="brand">
        ELHA
        <small>Admin Panel</small>
    </a>
    
    <ul class="nav flex-column mt-3">
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" 
               href="<?php echo BASE_URL; ?>/admin/index.php">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo in_array(basename($_SERVER['PHP_SELF']), ['products.php', 'product-add.php', 'product-edit.php']) ? 'active' : ''; ?>" 
               href="<?php echo BASE_URL; ?>/admin/products.php">
                <i class="bi bi-box"></i> Products
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'active' : ''; ?>" 
               href="<?php echo BASE_URL; ?>/admin/categories.php">
                <i class="bi bi-tags"></i> Categories
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'orders.php' ? 'active' : ''; ?>" 
               href="<?php echo BASE_URL; ?>/admin/orders.php">
                <i class="bi bi-cart"></i> Orders
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'customers.php' ? 'active' : ''; ?>" 
               href="<?php echo BASE_URL; ?>/admin/customers.php">
                <i class="bi bi-people"></i> Customers
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'complete-look.php' ? 'active' : ''; ?>" 
               href="<?php echo BASE_URL; ?>/admin/complete-look.php">
                <i class="bi bi-grid-3x3-gap"></i> Complete the Look
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'recommendation-rules.php' ? 'active' : ''; ?>" 
               href="<?php echo BASE_URL; ?>/admin/recommendation-rules.php">
                <i class="bi bi-magic"></i> Recommendations
            </a>
        </li>
        <li class="nav-item mt-3">
            <a class="nav-link text-danger" href="<?php echo BASE_URL; ?>/admin/logout.php">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </li>
    </ul>
</div>