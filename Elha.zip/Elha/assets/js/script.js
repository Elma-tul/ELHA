// =====================================================
// ELHA CUSTOM JAVASCRIPT
// =====================================================

document.addEventListener('DOMContentLoaded', function() {
    
    // =====================================================
    // AUTO-HIDE ALERTS
    // =====================================================
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(function() {
                alert.remove();
            }, 500);
        }, 5000);
    });
    
    // =====================================================
    // PRODUCT QUANTITY CONTROLS
    // =====================================================
    document.querySelectorAll('.quantity-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const input = this.closest('.quantity-control').querySelector('.quantity-input');
            let value = parseInt(input.value) || 1;
            if (this.dataset.action === 'increase') {
                value++;
            } else if (this.dataset.action === 'decrease') {
                value = Math.max(1, value - 1);
            }
            input.value = value;
            input.dispatchEvent(new Event('change'));
        });
    });
    
    
    // =====================================================
    // ADD TO CART (AJAX)
    // =====================================================
    document.querySelectorAll('.add-to-cart-btn').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const productId = this.dataset.productId;
            
            // Check if there's a quantity input nearby
            let quantity = 1;
            const qtyInput = this.closest('.product-card')?.querySelector('.quantity-input') || 
                             this.closest('.card-body')?.querySelector('.quantity-input');
            if (qtyInput) {
                quantity = parseInt(qtyInput.value) || 1;
            }
            
            const originalText = this.innerHTML;
            
            this.disabled = true;
            this.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Adding...';
            
            fetch('ajax/add-to-cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'product_id=' + productId + '&quantity=' + quantity
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Update cart count
                    updateCartBadge(data.total);
                    
                    showToast('Product added to cart!', 'success');
                    
                    this.innerHTML = '<i class="bi bi-check"></i> Added';
                    setTimeout(() => {
                        this.innerHTML = originalText;
                        this.disabled = false;
                    }, 2000);
                } else {
                    showToast(data.message || 'Error adding to cart', 'danger');
                    this.innerHTML = originalText;
                    this.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('An error occurred', 'danger');
                this.innerHTML = originalText;
                this.disabled = false;
            });
        });
    });
    
    // =====================================================
    // CART FUNCTIONALITY
    // =====================================================
    
    // Update cart quantity
    document.querySelectorAll('.update-cart').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const productId = this.dataset.productId;
            const action = this.dataset.action;
            const input = this.closest('.quantity-control').querySelector('.cart-qty');
            let quantity = parseInt(input.value) || 1;
            
            if (action === 'increase') {
                quantity++;
            } else if (action === 'decrease') {
                quantity = Math.max(1, quantity - 1);
            }
            
            updateCartQuantity(productId, quantity);
        });
    });
    
    // Manual quantity input change
    document.querySelectorAll('.cart-qty').forEach(function(input) {
        input.addEventListener('change', function() {
            const productId = this.dataset.productId;
            let quantity = parseInt(this.value) || 1;
            const max = parseInt(this.max) || 999;
            
            if (quantity < 1) quantity = 1;
            if (quantity > max) quantity = max;
            
            this.value = quantity;
            updateCartQuantity(productId, quantity);
        });
    });
    
    // Remove from cart
    document.querySelectorAll('.remove-from-cart').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const productId = this.dataset.productId;
            
            if (confirm('Remove this item from cart?')) {
                fetch('ajax/remove-from-cart.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'product_id=' + productId
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove item from DOM
                        const cartItem = document.querySelector('.cart-item[data-product-id="' + productId + '"]');
                        if (cartItem) {
                            cartItem.remove();
                        }
                        
                        updateCartBadge(data.total);
                        location.reload();
                    } else {
                        showToast(data.message || 'Error removing item', 'danger');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showToast('An error occurred', 'danger');
                });
            }
        });
    });
    
    // Update cart quantity function
    function updateCartQuantity(productId, quantity) {
        fetch('ajax/update-cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'product_id=' + productId + '&quantity=' + quantity
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update item total
                const cartItem = document.querySelector('.cart-item[data-product-id="' + productId + '"]');
                if (cartItem) {
                    const priceSpan = cartItem.querySelector('.item-total');
                    const priceText = cartItem.querySelector('.text-muted').textContent;
                    const priceMatch = priceText.match(/₹([0-9.]+)/);
                    if (priceMatch) {
                        const price = parseFloat(priceMatch[1]);
                        const total = price * quantity;
                        priceSpan.textContent = formatPrice(total);
                    }
                }
                
                // Update totals
                const subtotalEl = document.getElementById('cart-subtotal');
                const totalEl = document.getElementById('cart-total');
                if (subtotalEl) {
                    subtotalEl.textContent = formatPrice(data.subtotal);
                }
                if (totalEl) {
                    totalEl.textContent = formatPrice(data.subtotal);
                }
                
                updateCartBadge(data.total_items);
            } else {
                showToast(data.message || 'Error updating cart', 'danger');
                location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('An error occurred', 'danger');
        });
    }
    
    // Update cart badge function
    function updateCartBadge(total) {
        const cartBadge = document.querySelector('.cart-count');
        if (cartBadge) {
            if (total > 0) {
                cartBadge.textContent = total;
                cartBadge.style.display = 'inline';
            } else {
                cartBadge.style.display = 'none';
            }
        }
    }
    
    // =====================================================
    // WISHLIST TOGGLE (AJAX)
    // =====================================================
    document.querySelectorAll('.wishlist-toggle').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const productId = this.dataset.productId;
            const icon = this.querySelector('i');
            
            fetch('ajax/wishlist-toggle.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'product_id=' + productId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (data.action === 'added') {
                        icon.classList.remove('bi-heart');
                        icon.classList.add('bi-heart-fill');
                        this.classList.add('text-danger');
                        showToast('Added to wishlist!', 'success');
                    } else {
                        icon.classList.remove('bi-heart-fill');
                        icon.classList.add('bi-heart');
                        this.classList.remove('text-danger');
                        showToast('Removed from wishlist', 'info');
                        
                        // If on wishlist page, remove the card
                        if (window.location.pathname.includes('wishlist.php')) {
                            const card = this.closest('.product-card');
                            if (card) {
                                card.style.transition = 'opacity 0.3s';
                                card.style.opacity = '0';
                                setTimeout(() => card.remove(), 300);
                                setTimeout(() => {
                                    if (document.querySelectorAll('.product-card').length === 0) {
                                        location.reload();
                                    }
                                }, 500);
                            }
                        }
                    }
                    
                    // Update wishlist count badge
                    updateWishlistBadge(data.total);
                } else {
                    showToast(data.message || 'Error', 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('An error occurred', 'danger');
            });
        });
    });
    
    // Update wishlist badge function
    function updateWishlistBadge(total) {
        const wishlistBadge = document.querySelector('.wishlist-count');
        if (wishlistBadge) {
            if (total > 0) {
                wishlistBadge.textContent = total;
                wishlistBadge.style.display = 'inline';
            } else {
                wishlistBadge.style.display = 'none';
            }
        }
    }
    
    // =====================================================
    // COMPLETE THE LOOK - Add All to Cart
    // =====================================================
    document.getElementById('addAllToCart')?.addEventListener('click', function() {
        const addButtons = document.querySelectorAll('.add-to-cart-btn');
        const totalButtons = addButtons.length;
        let completed = 0;
        
        if (totalButtons === 0) {
            showToast('No items to add.', 'warning');
            return;
        }
        
        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Adding all items...';
        
        addButtons.forEach(function(btn) {
            const productId = btn.dataset.productId;
            
            fetch('ajax/add-to-cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'product_id=' + productId + '&quantity=1'
            })
            .then(response => response.json())
            .then(data => {
                completed++;
                if (completed === totalButtons) {
                    // Get updated cart count
                    fetch('ajax/get-cart-count.php')
                    .then(response => response.json())
                    .then(data => {
                        if (data.total > 0) {
                            updateCartBadge(data.total);
                        }
                    });
                    
                    showToast('All items added to cart!', 'success');
                    this.disabled = false;
                    this.innerHTML = '<i class="bi bi-check-circle me-2"></i>All Added!';
                    setTimeout(() => {
                        this.innerHTML = '<i class="bi bi-bag-plus me-2"></i>Add All Items to Cart';
                    }, 3000);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('Error adding items to cart', 'danger');
            });
        });
    });
    
    // =====================================================
    // TOAST NOTIFICATION
    // =====================================================
    function showToast(message, type = 'success') {
        const toastContainer = document.querySelector('.toast-container') || createToastContainer();
        const colors = {
            success: 'bg-success',
            danger: 'bg-danger',
            warning: 'bg-warning',
            info: 'bg-info'
        };
        
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white ${colors[type] || 'bg-primary'} border-0`;
        toast.role = 'alert';
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        toastContainer.appendChild(toast);
        
        const bsToast = new bootstrap.Toast(toast, { delay: 3000 });
        bsToast.show();
        
        toast.addEventListener('hidden.bs.toast', function() {
            this.remove();
        });
    }
    
    function createToastContainer() {
        const container = document.createElement('div');
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
        return container;
    }
    
    // =====================================================
    // PRICE FORMAT HELPER
    // =====================================================
    window.formatPrice = function(amount) {
        return '৳' + parseFloat(amount).toFixed(2);
    };
});